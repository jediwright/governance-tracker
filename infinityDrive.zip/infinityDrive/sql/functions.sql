
CREATE OR REPLACE FUNCTION bandwidth_buckets() RETURNS trigger AS '
BEGIN
	IF OLD.period < current_date THEN
		OLD.open = false;
		NEW.bytes_in = NEW.bytes_in - OLD.bytes_in;
		NEW.bytes_out = NEW.bytes_out - OLD.bytes_out;
		NEW.period = current_date;
		INSERT INTO bandwidth (period,bytes_in,bytes_out,account_id,open) VALUES (NEW.period,NEW.bytes_in,NEW.bytes_out,NEW.account_id,true);
		RETURN OLD;
	END IF;
	RETURN NEW;
END;
' LANGUAGE 'plpgsql';

CREATE TRIGGER bandwidth_update BEFORE UPDATE ON bandwidth FOR EACH ROW EXECUTE PROCEDURE bandwidth_buckets();

