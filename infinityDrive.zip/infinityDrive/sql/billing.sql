
-- account billing
CREATE TABLE invoices (
	invoice_id serial primary key,
	user_id int not null references users,
	invoice_date date default now(),
	invoice_amount numeric(10,2),
	closed bool default false
);

CREATE TABLE payments (
	payment_id serial primary key,
	invoice_id int not null references invoices,
	payment_date timestamp default now(),
	payment_amount numeric(10,2),
	completed bool default false,
	cc_type int,
	cc_last4 int
);

-- expense tracking
CREATE TABLE expense_recipients (
	recipient_id serial primary key,
	recipient text,
	type text
);

CREATE TABLE expenses (
	expense_id serial primary key,
	recipient_id integer,
	amount numeric(8,2),
	description	text,
	paid_on date,
	method text,
	checknum integer,
	cleared boolean,
	entered_by text,
	reimburse_to text,
	bar boolean default false
);

CREATE TABLE reimbursements (
	amount numeric(8,2) not null,
	reimbursement_to text not null,
	checknum integer,
	date_paid date default now()
);

