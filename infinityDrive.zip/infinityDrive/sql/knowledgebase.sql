
DELETE FROM knowledgebase;

INSERT INTO knowledgebase (document,title,search_terms,popularity,summary) VALUES (
	'setup-kde', 'Set up infinityDrive on KDE', 'kde linux setup konqueror', 5,
	'Instructions for configuring direct access to your infinityDrive through the KDE file manager, Konqueror.'
);
INSERT INTO knowledgebase (document,title,search_terms,popularity,summary) VALUES (
	'setup-macosx', 'Set up infinityDrive on Mac OS X', 'mac os x setup', 10,
	'Instructions for mounting your infinityDrive inside the Mac OS X Finder, so that you can copy files back and forth just like your local drives.'
);
INSERT INTO knowledgebase (document,title,search_terms,popularity,summary) VALUES (
	'setup-windows', 'Set up infinityDrive on Windows', 'windows xp nt 95 98 setup', 10,
	'Instructions for setting up access to your infinityDrive from the Windows Explorer, so that you can copy files back and forth just like your local drives.'
);
INSERT INTO knowledgebase (document,title,search_terms,popularity,summary) VALUES (
	'setup-cmdline', 'Access infinityDrive from the UNIX command line', 'setup unix cadaver command line', 0,
	'How to access your infinityDrive from the UNIX command line.'
);
INSERT INTO knowledgebase (document,title,search_terms,popularity,summary) VALUES (
	'setup-gnome', 'Set up infinityDrive on GNOME', 'setup gnome nautilus', 5,
	'Using the GNOME file manager, Nautilus, to access your infinityDrive.'
);
INSERT INTO knowledgebase (document,title,search_terms,popularity,summary) VALUES (
	'setup-macos9', 'Set up infinityDrive on Mac OS 9', 'setup mac os 9', 7,
	'Instructions for setting up access to your infinityDrive from Mac OS 9.'
);
INSERT INTO knowledgebase (document,title,search_terms,popularity,summary) VALUES (
	'ical', 'Share a calendar with Mac OS X iCal', 'mac os x ical calendar calender', 5,
	'Share a calender with friends or family using the iCal application and infinityDrive.'
);
INSERT INTO knowledgebase (document,title,search_terms,popularity,summary) VALUES (
	'korganizer', 'Share a calendar with KDE KOrganizer', 'korganizer kde calendar calender linux', 3,
	'Share a calender with friends or family using the KDE calendar application and infinityDrive.'
);
INSERT INTO knowledgebase (document,title,search_terms,popularity,summary) VALUES (
	'users', 'User administration', 'users administer people groups', 9,
	'If you have our Shared plan or higher, you can create users on your account to allow coworkers, friends, or family to access your infinityDrive.'
);
INSERT INTO knowledgebase (document,title,search_terms,popularity,summary) VALUES (
	'shares', 'Share administration', 'shares administer groups access permissions', 9,
	'If you have our Shared plan or higher, you can partition your drive into multiple shares, each with their own access permissions.'
);
INSERT INTO knowledgebase (document,title,search_terms,popularity,summary) VALUES (
	'speedup', 'Speeding up access to your infinityDrive', 'faster speed slow optimize access performance tips', 4,
	'A few tips on how to get maximal performance out of your infinityDrive.'
);
INSERT INTO knowledgebase (document,title,search_terms,popularity,summary) VALUES (
	'fileman', 'File Manager User''s Guide', 'file manager web', 8,
	'Everything you ever wanted to know about the web-based file manager.'
);
