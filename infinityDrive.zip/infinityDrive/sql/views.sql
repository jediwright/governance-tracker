
CREATE VIEW v_users AS SELECT * FROM users;
CREATE VIEW v_active_users AS SELECT * FROM v_users WHERE active=true;
CREATE VIEW v_users_lite AS SELECT user_id,username,full_name FROM users;

CREATE VIEW v_shares AS SELECT * FROM shares JOIN v_users USING (user_id);
CREATE VIEW v_shares_lite AS SELECT share_id,share,user_id as share_owner_id,username as share_owner,full_name as share_owner_full_name FROM v_shares;

CREATE VIEW v_invitations AS SELECT * FROM invitations LEFT JOIN v_shares_lite USING (share_id) LEFT JOIN v_users_lite USING (user_id);

CREATE VIEW v_expenses AS SELECT * FROM expenses NATURAL JOIN expense_recipients;

