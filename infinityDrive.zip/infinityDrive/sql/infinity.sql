
CREATE TABLE keywords (
	keyword_id serial primary key,
	keywords text
);

CREATE TABLE visitors (
	visitor_id serial primary key,
	cookie text not null,
	keyword_id int references keywords,
	first_visit timestamp default now()
);

CREATE TABLE plans (
	plan_id serial primary key,
	plan text not null,
	description text,
	price numeric(8,2),
	shares int,
	quota int   -- in MB
);

CREATE TABLE users (
	user_id serial primary key,
	username text not null unique,
	active boolean not null default true,

	password text,
	full_name text,
	email text,

	-- location --
	company text,
	city text,
	state text,
	zip text,
	country text,

	-- billing --
	next_billing date,
	cc text,
	exp text,
	cvv text,
	billing_name text,
	billing_address text,
	billing_city text,
	billing_state text,
	billing_zip text,
	billing_country text,

	plan_id int default 0,
	shares int not null, -- not counting personal share which they always have
	quota int not null,  -- in MB

	disk_usage bigint default 0,    -- in bytes
	over_quota bool default false,  -- write access denied until disk_usage goes below quota
	last_quota_check timestamp default now(),

	created timestamp default now(),
	first_login bool default false,
	visitor_id int references visitors,
	beta bool default false
);

CREATE TABLE shares (
	share_id serial primary key,
	share text,
	description text,
	user_id int not null references users
);

CREATE TABLE share_permissions (
	share_id int not null references shares on delete cascade,
	user_id int not null references users on delete cascade,
	read bool default false,
	write bool default false
);

CREATE TABLE invitations (
	share_id int not null references shares on delete cascade,
	user_id int references users on delete cascade,  -- CAN BE NULL IF THE INVITATION IS TO SOMEONE WHO HASN'T YET CREATED AN ACCOUNT
	email text not null,  -- always filled in regardless of whether they have an account
	hash text not null unique,
	sent_on timestamp default now()
);

CREATE TABLE bandwidth (
	user_id int not null references users,
	open bool default true not null,
	bytes_in int default 0 not null,
	bytes_out int default 0 not null,
	period date default now()
);

CREATE TABLE recovery
(
	recovery_id serial primary key,
	user_id int not null references users,
	recovery_email text not null,
	recovery_hash text not null,
	recovery_time timestamp not null default now(),
	recovery_completed boolean not null default false
);

CREATE TABLE knowledgebase (
	document_id serial primary key,
	document text not null,
	title text not null,
	summary text,
	search_terms text,
	popularity int default 0
);

CREATE TABLE surveys (
	survey_id serial primary key,
	user_id int not null references users,
	created timestamp default now(),
	completed timestamp,
	dont_show bool default false
);

CREATE TABLE survey_answers (
	survey_id int not null references surveys,
	question_id int not null,
	answer text
);

