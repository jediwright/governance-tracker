
DELETE FROM plans;
INSERT INTO plans (plan, price, shares, quota) VALUES ('Free',       null,   1,   50);
INSERT INTO plans (plan, price, shares, quota) VALUES ('Basic',      9.95,   3,   6144);
INSERT INTO plans (plan, price, shares, quota) VALUES ('Business',   50.00,  10,  20480);
INSERT INTO plans (plan, price, shares, quota) VALUES ('Enterprise', 900.00, 100, 204800);

