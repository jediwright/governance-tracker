#include <httpd.h>
#include <http_config.h>
#include <http_core.h>
#include <http_log.h>
#include <http_protocol.h>
#include <http_request.h>

#include "libpq-fe.h"

#define DOMAIN       "infinitydrive.net"
#define TEST_DOMAIN  "id.test"

#define DEBUG   0
#define DBG(expr) if (DEBUG) { expr; }

/*************************************************************************
 * exported module structure
 *************************************************************************/

static PGconn *inf_connection = NULL;

typedef struct 
{
  int       infinity_auth;  /* flag */
  char * 		pg_host;
  char * 		pg_port;
  char * 		pg_user;
  char * 		pg_password;
  char * 		pg_database;
} infinity_config;

module AP_MODULE_DECLARE_DATA infinity_module;

static const char * set_infinity_config(cmd_parms *cmd, infinity_config *conf, int flag) 
{

	if (! cmd->path) 
	{
		conf = ap_get_module_config(cmd->server->module_config, &infinity_module);
	}

	conf->infinity_auth = flag;

	return NULL;
}

static const command_rec mod_infinity_commands[] = 
{
  { "InfinityAuth", set_infinity_config, NULL, OR_ALL, FLAG,  "Usage: InfinityAuth (on|off)" },
  { NULL }
};

/**
 * merge different config levels
 */

static void * merge_config(apr_pool_t *p, void *base, void *override) 
{
	infinity_config *parent = base;
	infinity_config *child  = override;
	infinity_config *merge;

	merge = (infinity_config *)apr_pcalloc(p, sizeof(infinity_config));

	merge->infinity_auth = ( child->infinity_auth ? child->infinity_auth : parent->infinity_auth);

	return merge;
}

/**
 * setup of server
 */

static void * core_setup(apr_pool_t *p, server_rec *s) 
{
	infinity_config *conf;

	conf = (infinity_config *)apr_pcalloc(p, sizeof(infinity_config));
	conf->infinity_auth = 0;
	conf->pg_host = "localhost";
	conf->pg_user = "infinity";
	conf->pg_password = "9SL31xzp";
	conf->pg_port = "5432";
	conf->pg_database = "infinity";

	return conf;
}

/**
 * setup of folder level directives
 */

static void * dir_setup(apr_pool_t *p, char *dir) 
{
	// FIXME - what about dir?
	return core_setup(p, NULL);
}

// create a new buffer with sql special characters escaped
static char *sql_clean(request_rec *r, const char *string)
{
	char *clean = apr_palloc(r->pool, (strlen(string)*2)+1);
	PQescapeString(clean, string, strlen(string));
	return clean;
}

static char *run_query(request_rec *r, const char *query)
{
	PGresult *pg_result;
	char *val = NULL;

	const char *pg_host = "localhost";
	const char *pg_user = "infinity";
	const char *pg_password = "9SL31xzp";
	const char *pg_port = "5432";
	const char *pg_database = "infinity";

	DBG(ap_log_rerror(APLOG_MARK, APLOG_WARNING, 0, r, "[mod_infinity] - PG %s@%s %s: %s", pg_user, pg_host, pg_database, query));

	if (inf_connection == NULL) 
		inf_connection = PQsetdbLogin(pg_host, pg_port, NULL, NULL, pg_database, pg_user, pg_password);

	if (PQstatus(inf_connection) != CONNECTION_OK) 
	{
		ap_log_rerror(APLOG_MARK, APLOG_WARNING, 0, r, "db connection error (%s), resetting", PQerrorMessage(inf_connection));
		PQreset(inf_connection);

		if (PQstatus(inf_connection) != CONNECTION_OK) {
			ap_log_rerror(APLOG_MARK, APLOG_ERR, 0, r, "db connection error (%s), reset did not fix", PQerrorMessage(inf_connection));
			return NULL;
		}
	}

	pg_result = PQexec(inf_connection, query);

#define CLEANUP  { PQclear(pg_result); PQfinish(inf_connection); inf_connection = NULL; }
#define FAIL { CLEANUP; return NULL; }

	if (pg_result == NULL) 
		FAIL;

	if (PQresultStatus(pg_result) == PGRES_EMPTY_QUERY)
		FAIL;

	if (PQresultStatus(pg_result) != PGRES_TUPLES_OK) 
	{
		ap_log_rerror(APLOG_MARK, APLOG_ERR, 0, r, "!PGRES_TUPLES_OK: %s -- Query: %s", PQerrorMessage(inf_connection), query);
		FAIL;
	}

	if (PQntuples(pg_result) == 1) 
	{
		val = PQgetvalue(pg_result, 0, 0);
		if (val == NULL) {
			ap_log_rerror(APLOG_MARK, APLOG_ERR, 0, r, "PQgetvalue=null: %s -- Query: %s", PQerrorMessage(inf_connection), query);
			FAIL;
		}
	}

	CLEANUP;

	return val;
}

// convenience: select a single integer
static int select_one_val(request_rec *r, const char *sql)
{
	char *result = run_query(r, sql);
	if (!result)
		return 0;

	return atoi(result);
}

// convenience: select a single boolean
static int select_one_bool(request_rec *r, const char *sql)
{
	char *result = run_query(r, sql);
	if (!result)
		return 0;

	return (result[0] == 't');
}

#define BUFSIZE   10000
#define SMALLBUF  1024

// Use old style addressing (http://infinitydrive.net/myaccount)
int legacy_extract_account(request_rec *r, char *account, char *trim_uri)
{
	if (!(strcmp(r->hostname, DOMAIN) == 0 || strcmp(r->hostname, TEST_DOMAIN) == 0))
		return 0;

	DBG(ap_log_rerror(APLOG_MARK, APLOG_WARNING, 0, r, "[mod_infinity] legacy access, host|uri = %s|%s", r->hostname, r->uri));

	if (r->uri[0] != '/') return 0;

	// extract the account from the uri
	char *uri = r->uri + 1;
	int c;
	for (c = 0; c < SMALLBUF-1 && *uri && *uri != '/'; c++)
		account[c] = *uri++;
	account[c] = 0;

	if (trim_uri)
		apr_snprintf(trim_uri, SMALLBUF, "%s", uri);

	if (account[0] == 0)
		return 0;

	return 1;
}

int legacy_extract_share(request_rec *r, char *share)
{
	if (!(strcmp(r->hostname, DOMAIN) == 0 || strcmp(r->hostname, TEST_DOMAIN) == 0))
		return 0;

	if (r->uri[0] != '/') return 0;

	// skip the first item inside slashes, which should be the account name
	char *uri = r->uri + 1;
	int c;
	for (c = 0; c < SMALLBUF-1 && *uri && *uri != '/'; c++)
		uri++;

	if (*uri == '/')
		uri++;

	// the next token is the share
	for (c = 0; c < SMALLBUF-1 && *uri && *uri != '/'; c++)
		share[c] = *uri++;
	share[c] = 0;

	// if no trailing slash, this is not a share
	if (*uri != '/')
		share[0] = 0;

	return 1;
}

// turn a virtualhost like myaccount.infinitydrive.net into just myaccount
// for legacy uris, trims off the account name
void extract_account(request_rec *r, char *account, char *trim_uri)
{
	if (trim_uri)
		apr_snprintf(trim_uri, SMALLBUF, "%s", r->uri);

	if (legacy_extract_account(r, account, trim_uri))
		return;

	const char *ptr = r->hostname;
	int c;
	for (c = 0; c < SMALLBUF-1 && *ptr && *ptr != '.'; c++)
		account[c] = *ptr++;
	account[c] = 0;

	// if it's not followed by our master domain, it is invalid
	if (strcasecmp(ptr, "." DOMAIN) != 0 && strcasecmp(ptr, "." TEST_DOMAIN) != 0)
		account[0] = 0;
}

// Take everything between the first two slashes (or after the first slash and
// the string's end) to produce the share beind accessed.
// This assumes that their account is set up for shares, so anything in the top level
// directory is a share.  Do not call for personal plans.
void extract_share(request_rec *r, char *share)
{
	if (legacy_extract_share(r, share))
		return;

	const char *ptr = r->uri + 1;   // skip leading slash
	int c;
	for (c = 0; c < SMALLBUF-1 && *ptr && *ptr != '/'; c++)
		share[c] = *ptr++;
	share[c] = 0;

	// if no trailing slash, this is not a share
	//if (*ptr != '/')
	//	share[0] = 0;
}

// What type of access, read or write, is the current HTTP operation?
static const char *access_type(request_rec *r)
{
	if (strcmp(r->method,"PROPFIND") == 0 ||
	    strcmp(r->method,"OPTIONS") == 0 ||
	    strcmp(r->method,"GET") == 0 ||
	    strcmp(r->method,"HEAD") == 0)
		return "read";

	if (strcmp(r->method,"DELETE") == 0)
		return "delete";

	return "write";
}

// This function is the 1 guts of the share/permission access verification.
// When called, we know that the user has the correct password and belongs to
// the account.  What can_access determines is whether they have read or write
// access to the requested uri.
static int can_access(request_rec *r)
{
	const char *type = access_type(r);
	#define IS_WRITE  (type[0] == 'w')
	#define IS_DELETE (type[0] == 'd')
	#define IS_READ   (type[0] == 'r')

	char *user = r->user;

	char account[SMALLBUF];
	char uri[SMALLBUF];
	extract_account(r, account, uri);
	if (account[0] == 0) return 0;

	int is_root = (strcmp(user, account) == 0);

	char sql[BUFSIZE];

	DBG(ap_log_rerror(APLOG_MARK, APLOG_WARNING, 0, r, "[mod_infinity] - testing access for %s@%s", user, account));

	// FIXME should collapse the three account queries which follow into one that pulls all account data, for efficiency

	// we'll be using the account id a fair amount, so extract it now
	apr_snprintf(sql, BUFSIZE, "SELECT account_id FROM accounts WHERE account='%s'", sql_clean(r, account));
	int account_id = select_one_val(r, sql);
	if (account_id < 1)
		return 0;       // this shouldn't ever happen since they've already been authenticated

	// if they are over their disk usage quota, any write (which does not include delete) will be rejected
	if (IS_WRITE)
	{
		apr_snprintf(sql, BUFSIZE, "SELECT over_quota FROM accounts WHERE account_id=%d", account_id);
		int over_quota = select_one_bool(r, sql);
		if (over_quota) {
			DBG(ap_log_rerror(APLOG_MARK, APLOG_WARNING, 0, r, "[mod_infinity] - rejecting write, the account is over quota"));
			return 0;
		}
	}

	// for accounts with no user control (personal plan), do nothing - there's only one user and it can access everything
	apr_snprintf(sql, BUFSIZE, "SELECT plan_id FROM accounts WHERE account_id=%d", account_id);
	int plan_id = select_one_val(r, sql);
	if (plan_id == 0)
	{
		// there's only one user for personal plans - if there isn't, our data is out of sync
		if (!is_root) {
			ap_log_rerror(APLOG_MARK, APLOG_WARNING, 0, r, "[mod_infinity] - ERROR - personal account %s has a non-root user", account);
			return 0;
		}
		return 1;
	}

	DBG(ap_log_rerror(APLOG_MARK, APLOG_WARNING, 0, r, "[mod_infinity] - not a personal plan"));

	// top-level directory:
	if (strcmp(uri, "/") == 0)
	{
		DBG(ap_log_rerror(APLOG_MARK, APLOG_WARNING, 0, r, "[mod_infinity] - top level directory"));
		if (IS_READ) {
			DBG(ap_log_rerror(APLOG_MARK, APLOG_WARNING, 0, r, "[mod_infinity] - read, allow"));
			return 1;     // everyone can read it
		}
		else {
			DBG(ap_log_rerror(APLOG_MARK, APLOG_WARNING, 0, r, "[mod_infinity] - write, deny"));
			return 0;    // no one can write to it
		}
	}

	// root user has complete access to everything else
	if (is_root)
		return 1;

	char share[SMALLBUF];
	extract_share(r, share);

	DBG(ap_log_rerror(APLOG_MARK, APLOG_WARNING, 0, r, "[mod_infinity] - going to permissions table"));

	// If we get here, we're a non-root user accessing a share.  Hit the permissions table.
	if (IS_DELETE)
		type = "write";   // for permission purposes, delete is a write

	apr_snprintf(sql, BUFSIZE, "SELECT %s FROM share_permissions JOIN shares USING (share_id) JOIN users USING (user_id) WHERE shares.account_id=%d AND username='%s' AND share='%s'", type, account_id, sql_clean(r, user), sql_clean(r, share));
	return select_one_bool(r, sql);
}

static int mod_infinity_monitor(request_rec *r)
{
	char buf[BUFSIZE];

	infinity_config * sconf;
	infinity_config * dconf;
	infinity_config * conf;

	// FIXME really should have a config option to enable this per directory - currently auto on
	
	DBG(ap_log_rerror(APLOG_MARK, APLOG_WARNING, 0, r, "[mod_infinity] - mod_infinity_monitor"));

	sconf = ap_get_module_config(r->server->module_config, &infinity_module);
	dconf = ap_get_module_config(r->per_dir_config, &infinity_module);
	conf = merge_config(r->pool, sconf, dconf);

	const char *in = apr_table_get(r->headers_in, "Content-Length");

	int bytes_in = 0; 
	int bytes_out = 0; 

	char *user = r->user;

	if (in) bytes_in = atoi(in);
	bytes_out = r->bytes_sent;	
	
	apr_snprintf(buf, sizeof(buf), "UPDATE bandwidth SET bytes_in = bytes_in + %d, bytes_out = bytes_out + %d WHERE open is 1 AND account_id = (SELECT account_id FROM accounts WHERE account = '%s' AND active IS TRUE)", bytes_in, bytes_out, sql_clean(r, user));
	run_query(r, buf);

	return DECLINED;
}

static int str_ends_with(const char *string, const char *suffix)
{
	return (strcmp(suffix, string+strlen(string)-strlen(suffix)) == 0);
}

// Do a mod_rewrite translation to insert the acccount name into the uri
static int mod_infinity_translate(request_rec *r)
{
	// should really check the apache per-dir config, but it doesn't seem to work here
	if (!str_ends_with(r->hostname, DOMAIN) && !str_ends_with(r->hostname, TEST_DOMAIN))
		return DECLINED;
	// www. is the only subdomain we don't serve
	if (strcmp(r->hostname, "www." DOMAIN)==0 || strcmp(r->hostname, "www." TEST_DOMAIN)==0)
		return DECLINED;

	char account[SMALLBUF];
	char uri[SMALLBUF];
	extract_account(r, account, uri);

	DBG(ap_log_rerror(APLOG_MARK, APLOG_WARNING, 0, r, "[mod_infinity] starting uri = %s, account = %s", uri, account));

	// construct the local filename
	int size = strlen(uri) + strlen(account) + 20;
	char *buf = apr_palloc(r->pool, size);
	apr_snprintf(buf, size, "/dav/%s%s", account, uri);
	r->filename = buf;

	DBG(ap_log_rerror(APLOG_MARK, APLOG_WARNING, 0, r, "[mod_infinity] resulting filename is %s", buf));

	return OK;
}

// Authenticate a user by checking that their account, username, and password
// are all valid.  Does not check any directory permissions.
static int mod_infinity_check_user_id(request_rec *r)
{
	// ask apache to decode the password and put it into our buffer
	char *password;
	int res = ap_get_basic_auth_pw(r, (const char **)&password);
	if (res) return res;

	// decode the account from the hostname
	char account[SMALLBUF];
	extract_account(r, account, NULL);

	// remove anything after the @, which allows them to log in with the same (full) username as the
	// website, just for consistency.  might be nice to check the value at some point
	char *ptr = strchr(r->user, '@');
	if (ptr)
		*ptr = 0;

	DBG(ap_log_rerror(APLOG_MARK, APLOG_WARNING, 0, r, "[mod_infinity] authenticating %s@%s", r->user, account));

	// as an additional precaution, do not allow blank users or passwords
	if (strlen(r->user) < 1 || strlen(password) < 1)
		return HTTP_UNAUTHORIZED;

	// put it all into a select statement
	char sql[BUFSIZE];
	apr_snprintf(sql, BUFSIZE, "SELECT count(*) FROM users JOIN accounts USING (account_id) WHERE account='%s' AND username='%s' AND password='%s' AND active=true", sql_clean(r, account), sql_clean(r, r->user), sql_clean(r, password));
	char *result = run_query(r, sql);

	// if we get a match, they are let in
	if (result && atoi(result) == 1) {
		DBG(ap_log_rerror(APLOG_MARK, APLOG_WARNING, 0, r, "[mod_infinity] access granted", r->user, account));
		return OK;
	}

	// otherwise refuse them	
	DBG(ap_log_rerror(APLOG_MARK, APLOG_WARNING, 0, r, "[mod_infinity] access DENIED, result was %s", result));
	return HTTP_UNAUTHORIZED;
}

// Determine whether the user (already authenticated) has permission to access
// a directory as either read or write.
static int mod_infinity_access_checker(request_rec *r)
{
	DBG(ap_log_rerror(APLOG_MARK, APLOG_WARNING, 0, r, "[mod_infinity] - access_checker"));

	// merge apache configs for this virtualhost
	infinity_config *sconf = ap_get_module_config(r->server->module_config, &infinity_module);
	infinity_config *dconf = ap_get_module_config(r->per_dir_config, &infinity_module);
	infinity_config *conf = merge_config(r->pool, sconf, dconf);

	// if this module is not active in this directory, abort
	if (!conf->infinity_auth)
		return DECLINED;

	char *user = r->user;
	char *filename = r->uri;

	if (user == NULL || filename == NULL) {
		ap_log_rerror(APLOG_MARK, APLOG_WARNING, 0, r, "[mod_infinity] - blank user or uri, denying access");
		return HTTP_UNAUTHORIZED;
	}

	if (can_access(r)) {
		// DECLINED means do nothing - not decline user 
		// declineing to do th job of a authorization hook in this case (then it will try all other auth hooks installed)
		return DECLINED;
	}

	return HTTP_UNAUTHORIZED;
}

static void register_infinity_hooks(apr_pool_t *p)
{
	ap_hook_translate_name(mod_infinity_translate, NULL, NULL, APR_HOOK_FIRST);
	ap_hook_auth_checker(mod_infinity_access_checker, NULL, NULL, APR_HOOK_FIRST);
	ap_hook_check_user_id(mod_infinity_check_user_id, NULL, NULL, APR_HOOK_MIDDLE);
	//ap_hook_log_transaction(mod_infinity_monitor,NULL,NULL,APR_HOOK_MIDDLE);
}

module AP_MODULE_DECLARE_DATA infinity_module = {
	STANDARD20_MODULE_STUFF,
	dir_setup,        /* create per-directory config structure */
	merge_config,     /* merge per-directory(?) config str */
	core_setup,       /* create per-server config structure */
	merge_config,     /* merge per-server config ...*/
	mod_infinity_commands, /* command handlers */
	register_infinity_hooks
};


