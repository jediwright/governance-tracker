

import java.net.*;
import java.io.*;
import javax.net.*;
import javax.net.ssl.*;

class InfinityProxy
{
//	static protected String remoteHost = "www.infinitydrive.net";
	static protected String remoteHost = "infinitydrive.net";
	static protected int remotePort = 443;
	static protected int localPort = 7777;

	public static void handleSocket(Socket localCon) throws IOException
	{
		SSLSocketFactory factory = (SSLSocketFactory)SSLSocketFactory.getDefault();
		Socket tmpSocket = new Socket(remoteHost,remotePort);
		Socket remoteCon = factory.createSocket(tmpSocket,remoteHost,remotePort,true);
//		Socket remoteCon = new Socket("127.0.0.1",80);

		LocalPipe lp = new LocalPipe(localCon,remoteCon);
		RemotePipe rp = new RemotePipe(remoteCon,localCon);

		lp.start();
		rp.start();
	}

	public static void main(String[] argv) throws IOException
	{
		System.out.println("Hello world");

		ServerSocket server = ServerSocketFactory.getDefault().createServerSocket(localPort);
		while(true)
		{
			Socket socket = server.accept();
			System.out.println("Accepted a socket");
			handleSocket(socket);
		}
	}
}


