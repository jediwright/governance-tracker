
import java.io.*;
import java.net.*;
import java.util.*;
//import java.io.*;

public class LocalPipe extends Thread
{
	protected Socket in = null;
	protected Socket out = null;
	protected boolean header = true;
	protected List headers = new LinkedList();
	protected int contentLength = 0;

	LocalPipe(Socket _in, Socket _out)
	{
		in = _in;
		out = _out;
	}

	private void sendHeaders(OutputStream outs) throws IOException
	{
		Iterator i = headers.iterator();
		while(i.hasNext())
		{
			String tmp = (String)i.next();
			outs.write(tmp.getBytes());
		}
		headers.clear();
		if (contentLength > 0) 
		{
			header = false;
		}
	}

	private void processBuffer(byte[] buffer,int offset, int len) throws IOException
	{
		char ch, lastch = ' ';
		OutputStream outs = out.getOutputStream();
		StringBuffer b = new StringBuffer();
		if (header)
		{
			for (int i = 0; i < len; i++)
			{
				ch = (char)buffer[i];

				b.append(ch);
				if(ch  == '\n' && lastch == '\r') 
				{
					String h = b.toString();
					if (h.startsWith("Host: ")) h = "Host: infinitydrive.net\r\n";
					if (h.startsWith("Content-Length: ")) contentLength = Integer.parseInt(h.substring(16).trim());

					if (h.startsWith("Authorization: "))
					{
						//System.out.println("GOT AUTH HEADERS FROM CLIENT");
					}
					else if (h.length() == 2) 
//					if (h.length() == 2) 
					{
						//System.out.println("SEND HEADERS");
						headers.add("Authorization: Basic cXVldGljbzphYmMxMjM=\r\n");
						headers.add("\r\n");
						sendHeaders(outs);
//						outs.write(buffer,(i+1),len - (i+1)); header = true;
						processBuffer(buffer,(i+1),len - (i+1));
						break;
					}
					else
					{
						headers.add(h);
					}
					b = new StringBuffer();
				}
				lastch = ch;
			}
		}
		else
		{
			//System.out.println("YYY DO SOMETHING WITH OFFSET HERE");
			if (len <= contentLength)
			{
				//System.out.println("WOULD WRITE [ body ]: offset : " + offset + " len = " + len );
//				System.out.print((new String(buffer)).substring(offset,len));
//				System.out.print((new String(buffer)).substring(offset,offset+len));
				outs.write(buffer,offset,len);
				contentLength -= len;
			}
			else
			{
				throw new IOException("What the fuck : len = " + len + " and contentLength = " + contentLength);
			}
			if (contentLength == 0) 
			{
				//System.out.println("Content-Length Now Zero: Setting Header back to true");
				header = true;
			}
//			else System.out.println("Content-Length NOT Done: " + contentLength);
		}
//		if (offset == 0) outs.write(buffer,offset,len);
	}

	public void run() 
	{
		try
		{
			InputStream ins = in.getInputStream();
			byte[] buffer = new byte[1000];
			while(true)
			{
				if (true || ins.available() > 0)
				{
					int len = ins.read(buffer);
					if (len == -1) return;
					processBuffer(buffer,0,len);
//					System.out.println("LOCAL: " + len );
//					System.out.print("[LOCAL]\n"); System.out.print(new String(buffer)); System.out.print("[/LOCAL]\n");
//					outs.write(buffer,0,len);
				}
			}
		}
		catch (Exception e)
		{
			//System.out.println("LOCAL SOCKET EXCEPTION");
			e.printStackTrace();
		}
		finally
		{
			try { in.close(); } catch (Exception e2) {}
			try { out.close(); } catch (Exception e2) {}
		}
	}
}

