
import java.io.*;
import java.net.*;
//import java.io.*;

public class RemotePipe extends Thread
{
	protected Socket in = null;
	protected Socket out = null;
	RemotePipe(Socket _in, Socket _out)
	{
		in = _in;
		out = _out;
	}

	public void run() 
	{
		try
		{
			InputStream ins = in.getInputStream();
			OutputStream outs = out.getOutputStream();
			byte[] buffer = new byte[1000];
			while(true)
			{
				if (true || ins.available() > 0)
				{
					int len = ins.read(buffer);
					if (len == -1) return;
//					System.out.println("REMOTE: " + len);
//					System.out.print("[REMOTE]\n"); System.out.print(new String(buffer)); System.out.print("[/REMOTE]\n");
					outs.write(buffer,0,len);
				}
			}
		}
		catch (Exception e)
		{
//			System.out.println("REMOTE SOCKET EXCEPTION"); e.printStackTrace();
		}
		finally
		{
			try { in.close(); } catch (Exception e2) {}
			try { out.close(); } catch (Exception e2) {}
		}
	}
}

