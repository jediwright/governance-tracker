<? $secure_page = 1; include("defs.inc"); ?>
<?
	## variables
	$fields = array("username", "password", "verify_password", "full_name", "email", "company", "city", "state", "zip", "country");

	$shownames = array(
		"full_name" => "Your name",
		"state" => "State or Providence",
		"zip" => "Zip or Postal Code",
	);

	$comments = array(
		"company" => "optional",
	);

	$errors = array(
		"too short" => "The field shown below is too short.  Please correct and resubmit.",
		"nomatch" => "The passwords did not match.  Please retype both passwords making sure they are the same.",
		"nodata" => "The field shown below must be filled in.  Please correct and resubmit.",
		"invalid" => "The field shown below has an invalid format.  Please correct and resubmit.",
		"inuse" => "That username is already in use, please choose another.",
		"bademail" => "We can't seem to send email to that address.  Please check to make absolutely sure it is correct.",
	);

	include("country.inc");

	## functions
	function signup_error($error, $offenders)
	{
		global $fields, $_REQUEST;
		$ret = array("error" => $error, "offenders" => join(",", $offenders));
		foreach ($fields as $f) $ret{$f} = $_REQUEST{$f};
		$ret{override_email} = request("override_email");
		redirect("signup.php?" . http_build_query($ret));
	}

	## begin page code

	// Is this an invitation?  If so, display things a little differently.
	$hash = request("invitation");
	if ($hash)
	{
		$invitation = select_row("SELECT * FROM v_invitations WHERE hash=" . sql_quote($hash));
		if (!$invitation)
			error("There is no such invitation in our database.  Did you cut and paste the complete URL?");
	}

	if (request("signup"))
	{
		### verify the data
		$p = array();
		foreach ($fields as $f)
		{
			$val = trim(request($f));
			if ($f == "username")
			{
				$val = strtolower($val);
				$val = preg_replace("/[^a-z0-9_]/", "", $val);
				if (strlen($val) <= 3)
					$error = "tooshort";

				if (select_one("SELECT count(*) FROM users WHERE username=" . sql_quote($val)) > 0)
					$error = "inuse";
			}
			else if ($f == "verify_password")
			{
				if ($val != request("password"))
					$error = "nomatch";
				if (strlen($val) <= 3)
					$error = "tooshort";
			}
			else if ($f == "email")
			{
				$val = clean_email($val);
				if (!check_email_format($val))
					$error = "invalid";
				if (request("override_email") != "on" && !$invitation)
					if (!validate_email($val))
						$error = "bademail";
			}

			# all fields but one require an entry
			if ($f != "company")
				if (strlen($val) < 1)
					$error = "nodata";

			if ($error)
				signup_error($error, array($f));

			if ($f != "verify_password")
				$p[$f] = $val;
		}

		### set the visitor id, if any
		$cookie = $_COOKIE["INFINITY"];
		$visitor_id = select_one("SELECT visitor_id FROM visitors WHERE cookie=" . sql_quote($cookie));
		$p[visitor_id] = $visitor_id;

		sql_query("BEGIN");

		### create the new user
		$free = get_plan_byname("Free");
		$p[plan_id] = $free[plan_id];
		$p[shares] = $free[shares];
		$p[quota] = $free[quota];
		$user_id = sql_insert("users", $p);
		$username = $p[username];

		### create them an initial private share
		$share = array(
			"share" => PERSONAL_SHARE_NAME,
			"description" => "Your personal files which you do not want to share with anyone else.",
			"user_id" => $user_id);
		$share_id = create_share($share);
		if (!$share_id)
			error("Trouble creating your infinityDrive home", "couldn't create dav share, cheeck permissions?");

		$fname = share_local_path($share_id) . "/Welcome.txt";
		$fp = fopen($fname, "w");
		fputs($fp, "\nWelcome to infinityDrive!\n\nYou have successfully mounted your virtual hard drive.  Now you can copy files to and from it just like your local hard drive - from anywhere in the world.\n\n(You will probably want to delete this file once you copy some of your own here.)\n");
		fclose($fp);
		chmod($fname, 0644);

		### give them access to the invitation share
		if ($invitation)
		{
			$p = array(
				"share_id" => $invitation[share_id],
				"user_id" => $user_id,
				"read" => true,
				"write" => true
			);
			sql_insert("share_permissions", $p);

			sql_delete("invitations", "hash=" . sql_quote($invitation[hash]));
		}

		sql_query("COMMIT");

		# log them in (which will take them to the welcome page)
		login($username);
	}

	$error = request("error");
	$offenders = request("offenders");
	if (strlen($offenders) < 1) $offenders = array();
	else $offenders = split(",", $offenders);

	$focus = count($offenders) > 0 ? $offenders[0] : $fields[0];
	$onload = "javascript: document.ff.$focus.focus()";
?>
<? include("template.inc"); ?>

<div id="maincolumn">
	
	<div id="leftsub">
		<h1>Create an infinityDrive account completely free!</h1>
		<? if ($invitation) { ?>
		<p><b><?= $invitation[share_owner_full_name] ?></b> has invited you to share their files under a shared folder titled <b><?= $invitation[share] ?></b>.  To get access, you need only to create an infinityDrive account by filling in the form below.</p>
		<? } else { ?>
		<p>Get started using your own personal infinityDrive in just seconds.  No credit card is required!  Once you've experienced the power and convenience of your virtual hard drive, you'll never want to go back.</p>
		<? } ?>
		<?
			if ($error)
			{
				echo '<p id="signuperror">';
				echo $errors{$error};
				echo '</p>';
			}
		?>

		<div id="signupform">
			<form method="post" name=ff>
			<? if ($invitation) { ?>
				<input type="hidden" name="hash" value="<?= $invitation[hash] ?>">
			<? } ?>

			<div id="signupformheader">Account Information</div>
			<?
				foreach ($fields as $f)
				{
					echo "<div id=\"formfield\">";
					$showname = notnull($shownames[$f], fieldname($f));
					echo $showname;
					echo "</div>";

					$type = (strstr($f, "password")) ? "password" : "text";

					$id = "formentry" . (in_array($f, $offenders) ? "error" : "");
					echo "<div id=\"$id\">";

					$val = request($f);
					if ($f == "email")
						$val = notnull($val, $invitation[email]);

					if ($f == "country")
						echo makeselect($f, $countries, $val);
					else {
						$size = 20;
						echo "<input type=\"$type\" name=\"$f\" value=\"$val\" size=\"$size\">";
					}
					if ($comments{$f})
						echo " &nbsp; <i>" . $comments{$f} . "</i>";
					echo "</div>";

					if ($f == "email" && ($error == "bademail" || $_REQUEST['override_email']))
					{
						echo '<div id="bademail">If you are absolutely certain you entered your email address<br>correctly, check this box to override email verification: ';
						echo makecheckbox("override_email", ($_REQUEST['override_email'] == "on") ? 't' : null);
						echo '</div>';
					}
				}

			?>
			<div id="formsubmit">
				<? if ($dev) { ?>
					<script language="javascript">
						function autofill()
						{
							var f = document.ff;
							f.username.value = "test";
							f.password.value = f.verify_password.value = "abc123";
							f.full_name.value = "John Smith";
							f.email.value = "hiro@dusk.org";
							f.city.value = "Somewhere";
							f.state.value = "CA";
							f.zip.value = "12345";
						}
					</script>
					<span style="margin-right: 1em;">
						<input type="button" value="Autofill" onClick="autofill()">
					</span>
				<? } ?>
				<input type="submit" name="signup" value="Sign Up">
			</div>
			</form>
			<div id="clear"></div>
		</div>
	</div>
</div>

<div id="sidecolumn">
	<div id="leftsub">
	<h1>Plans</h1>

	<div id="planheader">click on any plan name for details</div>

	<table id="plans">
	<tr id="plansmallheader"><td>Plan</td><td>Cost</td><td>Quota</td><td>Shares</td></tr>
	<?
		$plans = get_plans();
		$count = 0;
		foreach ($plans as $p)
		{
			echo '<tr id="plans' . $count++ . '">';
			echo td("<a href=\"plandetail.php?plan=" . urlencode($p[plan]) . "\">{$p[plan]}</a>");
			echo td(money($p[price]));
			echo td(prettysize($p[quota] * MB));
			echo td($p[shares]);
			echo "</tr>";
		}
	?>
	</table>

	<p id="plannotes">Choose the plan that best suits your needs.  Upgrade, downgrade, or cancel at any time - instantly.  No startup costs, no cancelation costs, and no hidden fees.</p>

	<div id="clear"></div>
	</div>
</div>

<div id="clear"></div>

<? include("template.inc"); ?>
