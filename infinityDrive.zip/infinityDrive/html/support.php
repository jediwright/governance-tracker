<? include("template.inc"); ?>

<div id="maincolumn">
	
	<div id="leftsub">
		<h1>Support</h1>
		<img src="images/people/operator.jpg" style="float: left; margin: 1em; border: 1px solid black;" />
		<p>infinityDrive is stable and easy-to-use.  Most of our customers never need support, except occassionally with the initial setup.  But when you do need some assistance, we're here for you.</p>
		<p>For Personal and Shared plans, we offer email support with quick response times by knowlegable engineers.</p>
		<p>For Business and Enterprise plans, phone support is available on our toll-free number from 9am - 9pm PST.</p>
		<p>To contact us for non-support issues such as Enterprise sales inquiries, please visit the <a href=contact.php>contact page</a>.</p>
	</div>
</div>

<?= showrightcol() ?>

<div id="clear"></div>

<? include("template.inc"); ?>
