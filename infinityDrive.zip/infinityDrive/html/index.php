<? require_once("tracker.inc"); ?>
<? include("template.inc"); ?>

<div id="leftcolumn">

	<div id="leftsub">
		<h1>About infinityDrive</h1>
		<img src="images/shared.png" style="margin: 1em; float: right;" />
		<p>infinityDrive is a virtual disk drive that you can access from any computer.  Don't carry files
		around on CD-R or zipdisk; copy them to your infinityDrive instead.  Need more space to store
		pictures, music, movies, and documents?  No problem, you can expand your infinityDrive disk to
		any size, instantly - and <i>without</i> disrupting your existing files!</p>
		<p>infinityDrive Shared allows you to create accounts for your friends, family, or coworkers to
		be able to instantly share files.  Collaborate on documents, share calendar files, trade
		music - it couldn't be easier with infinityDrive.</p>
		<p id="learnmore"><a href=howitworks.php>learn more &gt;&gt;</a></p>
		<div id="clear"></div>
	</div>
</div>

<div id="rightcolumn">
	<div id="leftsub">
		<h1>Use infinityDrive For...</h1>
		<ul>
			<li>Backup</li>
			<li>Sharing files between home and work</li>
			<li>Collaborating with coworkers</li>
			<li>Shared calendaring</li>
		</ul>
		<p id="learnmore"><a href="solutions.php">learn more &gt;&gt;</a></p>
	</div>

	<div id="leftsub">
		<h1>infinityDrive Personal</h1>
		<ul>
			<li>6 gigabytes of storage</li>
			<li>No software to install</li>
			<li>Works with any operating system</li>
			<li>Access just like a local drive</li>
			<a href="signup.php"><img src="images/signup.png" style="margin-right: 1em; border: 0px;" /></a>
			<li>$9.95/month</li>
			<li>No setup or cancelation fees</li>
		</ul>

	</div>

</div>

<div id="clear"></div>

<? include("template.inc"); ?>
