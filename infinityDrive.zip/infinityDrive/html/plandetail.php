<? require_once("defs.inc"); ?>
<?
	$plan = $_REQUEST['plan'];
	for ($i = 0; $i < count($plans); $i++)
		if ($plans[$i][0] == $plan)
		{
			$plannr = $i;
			$p = $plans[$i];
			$nextplan = $plans[$i+1];
			break;
		}

	if (!isset($plannr))
		redirect("plans.php");
?>
<? include("template.inc"); ?>

<div id="maincolumn">
	
	<div id="leftsub">
		<h1>Plan Detail</h1>

		<div id="plantitle">infinityDrive <?= $p[0] ?></div>

		<table id="planstats">
		<tr><td>Storage size</td><td><?= $p[2] ?>GB</div>
		<tr><td>Cost per month</td><td><?= money($p[1]) ?></div>
		<tr><td>Number of users</td><td><?= $p[3] ?></div>
		<tr><td>Number of shares</td><td><?= $p[4] ?></div>
		</table>

		<div id="planmain">
			<p><?= $p[5] ?></p>
			<? if ($nextplan) { ?>
				<div id="planupgrade"><a href="plandetail.php?plan=<?= $nextplan[0] ?>">or upgrade to infinityDrive <?= $nextplan[0] ?> for an additional <?= money($nextplan[1] - $p[1]) ?> &gt;&gt;</a></div>
			<? } ?>
		</div>

		<div id="clear"></div>

	</div>
</div>

<?= showrightcol() ?>

<div id="clear"></div>

<? include("template.inc"); ?>
