<? include("template.inc"); ?>

<div id="maincolumn">
	
	<div id="leftsub">
		<h1>Beta Test infinityDrive</h1>
		<p>Sorry, but the infinityDrive beta signup is now closed.  You may still sign up for a free trial account using our <a href="signup.php">regular signup form</a>.
	</div>
</div>

<div id="sidecolumn">
	<div id="leftsub">
	<h1>Plans</h1>

	<div id="planheader">click on any plan name for details</div>

	<table id="plans">
	<tr id="plansmallheader"><td>Plan</td><td>Cost</td><td>Size</td><td>Users</td><td>Shares</td></tr>
	<?
		foreach ($plans as $p)
		{
			echo '<tr id="plans' . $p[0] . '">';
			echo td("<a href=\"plandetail.php?plan=$p[0]\">$p[0]</a>");
			echo td(money($p[1]));
			echo td($p[2] . " GB");
			echo td($p[3]);
			echo td($p[4]);
			echo "</tr>";
		}
	?>
	</table>

	<p id="plannotes">Choose the plan that best suits your needs.  Upgrade, downgrade, or cancel at any time - instantly.  No startup costs, no cancelation costs, and no hidden fees.</p>

	<div id="clear"></div>
	</div>
</div>

<div id="clear"></div>

<? include("template.inc"); ?>
