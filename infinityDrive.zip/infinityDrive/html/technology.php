<? include("template.inc"); ?>

<div id="maincolumn">
	
	<div id="leftsub">
		<h1>infinityDrive Technology Overview</h1>
		<img src="images/raid.png" style="float: right; margin: 1em; border: 1px solid gray;" />
		<p>
		infinityDrive uses multiply redundant servers running large-disk RAID arrays to
		provide nearly limitless drive space and massive data throughput.  Our
		software is a combination of secure, stable
		<a href="http://www.opensource.org/" target=_black>Open Source</a> components and
		custom-written backend software which produces a secure, reliable remote storage
		solution.</p>
		<p>
		We use only the best of the best for our hosting facilities.  Raised floors,
		armed guards, and biometric identification keeps your data safer than it
		could ever be in your home or office.
		</p>
		<img src="images/colo.jpg" style="float: left; margin: 1em; border: 1px solid gray;" />
		<p>
		All of our solutions are completely cross-platform.  Naturally we support
		all versions of Windows, but Mac OS and Linux are not second-class
		citizens to us.  infinityDrive is the perfect solution for heterogeneous
		offices, and (should you chose to use it for sharing files with clients) it
		will thrill clients with its flexibility.
		</p>
		<p>
		Basic infinityDrive support works with any browser and most modern operating systems
		through local file managers - without any custom software install.  Some of
		our additional features are available via free software downloads from within
		the account login on the site.
		</p>
		<p>
		The infinityDrive technology was lovingly hand-crafted by our top-notch
		engineering team.  Members of our team have secured systems for government
		and military clients, and major banks.  The infinityDrive engineering team is
		avaliable for security and network consulting at a rate of $500/hr.
		<a href=contact.php>Contact</a> a sales representative for details.
		</p>
		<div id="clear"></div>
	</div>
</div>

<?= showrightcol(); ?>

<div id="clear"></div>

<? include("template.inc"); ?>
