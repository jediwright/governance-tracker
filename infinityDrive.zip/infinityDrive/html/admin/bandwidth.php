<? require("template.inc"); ?>

<div id="mainheader">
	Usage Stats - <a href=index.php>Main Menu</a>
</div>

<form>
	<div>
	<? 
		echo "Bandwidth Info From ";
		echo make_date_select("begin",$_REQUEST,1,1,2005); 
		echo " To ";
		echo make_date_select("end",$_REQUEST,date("d"),date("m"),date("Y")); 
	?>
	</div>
	<input type=submit name=submit value="Submit">
</form>

<?

	if ($_REQUEST[submit])
	{
		$sql = "SELECT sum(bytes_in) as in, sum(bytes_out) as out, sum(bytes_in + bytes_out) as total, account,account_id FROM bandwidth JOIN accounts USING (account_id) WHERE period BETWEEN DATE '$_REQUEST[begin_year]-$_REQUEST[begin_month]-$_REQUEST[begin_day]' AND DATE '$_REQUEST[end_year]-$_REQUEST[end_month]-$_REQUEST[end_day]' GROUP BY account,account_id ORDER BY total DESC";
		$data = select_all($sql);

		$total = array();

		echo "<table id=bandwidth>\n";
		echo "<tr id=bandwidthheader> <th>Username</th><th>Bytes In</th><th>Bytes Out</th><th>Total</th><th>Graph</th></tr>\n";
		$high = $data[0][total];

		for ($i = 0; $i < count($data); $i++)
		{
			$d = $data[$i];

			$total[in] += $d[in];
			$total[out] += $d[out];
			$total[total] += $d[total];

			$w = floor(100 * $d[total] / $high);
			$color = ($w > 90 ? "red" : "green" ); 
			echo "<tr>\n";
			echo "  <td><a href=account.php?account=$d[account]>$d[account]</a></td><td>".prettysize($d[in])."</td><td>".prettysize($d[out])."</td><td>".prettysize($d[total])."</td>";
			echo "<td><div style='height: 10px; background-color: $color; width: ${w}px'></td>\n";
			echo "</tr>\n";
		}
		echo "<tr><th>Total</th><td>".prettysize($total[in])."</td><td>".prettysize($total[out])."</td><td>".prettysize($total[total])."</td><td></td></tr>\n";
		echo "</table>\n";
	}
?>

<? require("template.inc"); ?>
