<?
	require_once("defs.inc");

$fields = array( 
	'Password' => 'password',
	'Contact Name' => 'contact_name',
	'Companty' => 'company',
	'Email' => 'email',
	'CC' => 'cc',
	'Exp' => 'exp',
	'CVV' => 'cvv',
	'Billing Name' => 'billing_name',
	'Address' => 'address',
	'City' => 'city',
	'State' => 'state',
	'Zip' => 'Zip',
	'Plan' => 'plan');

	if ($_REQUEST[action] == "Update")
	{
		$sql_fields = array_values($fields);
		$sql_values = array();

		foreach($sql_fields as $f) $sql_values[$f] = $_REQUEST[$f];
		$sql_values[hash] = md5($_REQUEST[password]);

		sql_update_assoc("accounts",$sql_values," account = '$_REQUEST[account]'");

		redirect("account.php?account=$_REQUEST[account]");
	}

?>
<? require("template.inc"); ?>

<div id="mainheader">
	Edit Account - <a href=index.php>Main Menu</a>
</div>

<div id=accounts>
<form>
<input type=hidden name=account value="<?= $_REQUEST[account]?>">
<?

$sql = "SELECT account_id,account,password,active,contact_name,company,email,cc,exp,cvv,billing_name,address,city,state,zip,country,created::date as created,plan FROM accounts WHERE account = '$_REQUEST[account]'";
$data = select_row($sql);


?>

<div id=editaccount>
<?
	foreach ($fields as $name => $value)
	{
		echo "<div id=editaccountlabel>$name</div><div id=editaccountinput><input name=\"$value\" value=\"".  htmlspecialchars($data[$value])."\"></div>";
	}
?>
</div>
<br clear=all>
<input type=submit name=action value="Update">
</form>
</div>

<? require("template.inc"); ?>
