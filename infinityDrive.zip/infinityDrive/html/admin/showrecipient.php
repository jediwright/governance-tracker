<? include("template.inc"); ?>
<?
	$id = $_REQUEST['id'];
	$data = select_row("SELECT * FROM expense_recipients WHERE recipient_id=$id");
	$expenses = select_all("SELECT * FROM expenses WHERE recipient_id=$id ORDER BY paid_on DESC");
?>

<br>
<table cellspacing=0 cellpadding=4 border=1 align=center>
<tr><th colspan=5 bgcolor=lightgray><?= $data{'name'} ?></th></tr>
<?
	$fields = array("amount", "description", "paid_on", "method", "checknum");
	echo fieldheaders($fields);

	foreach ($expenses as $e)
	{
		echo "<tr>";
		foreach ($fields as $f)
			echo td($e{$f});
		echo "</tr>";

		$sum += $e{'amount'};
	}

	echo "<tr><th colspan=5>" . money($sum) . "</td></tr>";
?>
<tr><th colspan=5><a href=expense.php?id=<?= $id ?>>enter a new expense</a></th></tr>
</table>

<? include("template.inc"); ?>
