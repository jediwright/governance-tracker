<? $access_required = 35; include("defs.inc"); ?>
<?
	$fields = array("recipient_id", "amount", "description", "method", "checknum", "reimburse_to", "bar", "paid_on");

	if ($_REQUEST['pay'])
	{
		$params = array();
		foreach ($fields as $k)
			$params[$k] = $_REQUEST[$k];

		if ($params[bar] == "on") $params[bar] = "t";
		if ($params[reimburse_to] == "--") unset($params[reimburse_to]);
		$params[entered_by] = $_user;

		sql_insert("expenses", $params);

		$expense_id = select_one("SELECT currval('expenses_expense_id_seq')");

		redirect("findrecipient.php");
	}

	$recipient_id = $_REQUEST['id'];
	if ($recipient_id)
		$onload = "ff.amount.focus();";

	#$reim = select_vertical("SELECT * FROM adminusers WHERE disabled is not true");
	#$reim = array_merge(array("--"), $reim);
	$reim = array("--", "adam", "orion");

	$javascript = "
		function switchReim()
		{
			if (ff.method.selectedIndex == 0)
				ff.reimburse_to.selectedIndex = " . (array_search($_user, $reim)) . ";
			else
				ff.reimburse_to.selectedIndex = " . (array_search("--", $reim)) . ";
		}
	";
?>
<? include("template.inc"); ?>
<?
	if ($_REQUEST['received'])
		echo "<h3>Expense Received</h3>";
?>

<br>
<table cellspacing=0 cellpadding=4 border=0><tr valign=top>
<td>

	<form name=ff>
	<table cellspacing=0 cellpadding=4 border=1>
	<tr><th colspan=2 bgcolor=lightgray>Enter an Expense</th></tr>
	<?
		foreach ($fields as $field)
		{
			$input = $val = $method = null;
			$reimburse_to = $_user;

			if ($field == "recipient_id")
			{
				$recips = select_vertical_assoc("SELECT recipient_id,name FROM expense_recipients ORDER BY name DESC");
				$input = makeselect($field, $recips, $recipient_id);
				$input .= " &nbsp; <font size=-1><a href=recipient.php>add</a></font>";
			}
			else if ($field == "paid_on")
				$val = notnull($val, date("Y-m-d"));
			else if ($field == "method")
				$input = makeselect($field, array("cc", "check", "ach", "paypal", "cash"), $method, "onChange='javascript:switchReim()'");
			else if ($field == "reimburse_to")
				$input = makeselect($field, $reim, $reimburse_to);
			else if ($field == "bar")
				$input = makecheckbox($field);

			if (!$input)
				$input = "<input type=text name=$field value=\"$val\">";

			echo "<tr><th>" . ucwords(preg_replace("/_/", " ", $field)) . "</th><td>$input</td></tr>";
		}
	?>
	<tr><th colspan=2><input name=pay type=submit value="Submit"></th></tr>
	</table>
	</form>

</td>

<? if ($recipient_id) { ?>
<td>
<?
	$clauses = array(
		"This Recipient" => "recipient_id=$recipient_id",
		"This Type" => "type=(select type from expense_recipients where recipient_id=$recipient_id)",
		"All Recent" => "true"
	);
	foreach ($clauses as $title => $clause)
	{
		echo "<table cellspacing=0 cellpadding=4 border=1>";
		$fields2 = array("name", "type", "description", "amount", "paid_on");

		echo "<tr bgcolor=#60c090><th colspan=" . count($fields2) . ">$title</th></tr>";
		echo fieldheaders($fields2);

		$recent = select_all("SELECT * FROM v_expenses WHERE $clause ORDER BY paid_on DESC LIMIT 3");
		foreach ($recent as $r)
		{
			echo "<tr>";
			foreach ($fields2 as $f)
			{
				$val = $r{$f};
				$extra = null;
				if ($f == "description")
					$extra = "class=normal";
				echo td($val, $extra);
			}
			echo "</tr>";
		}
		echo "</table><p>";
	}
?>

</td>
<? } ?>

</tr></table>

<? include("template.inc"); ?>
