<? include("defs.inc"); ?>
<?
	$fields = array("name", "type");

	if ($_REQUEST['add'])
	{
		$params = array();
		foreach ($fields as $k)
			$params[$k] = $_REQUEST[$k];
		sql_insert("expense_recipients", $params);
		$id = select_one("SELECT currval('expense_recipients_recipient_id_seq')");
		redirect("expense.php?id=$id");
	}
?>
<? include("template.inc"); ?>

<form>
<table align=center><tr valign=top>

<td>
	<table cellspacing=0 cellpadding=4 border=1>
	<tr><th colspan=2 bgcolor=lightgray>Add New Expense Recipient</th></tr>
	<?
		foreach ($fields as $field)
		{
			$input = "<input type=text name=$field>";
			echo "<tr><th>" . ucwords(preg_replace("/_/", " ", $field)) . "</th><td>$input</td></tr>";
		}
	?>
	<tr><th colspan=2><input name=add type=submit value="Add"></th></tr>
	</table>
	</form>
</td>

<td>&nbsp;</td>

<td>
	<table cellspacing=0 cellpadding=4 border=1>
	<?
		$types = select_vertical("SELECT distinct type FROM expense_recipients ORDER BY type DESC");
		$x = 0;
		$WIDTH = 5;
		foreach ($types as $type)
		{
			if ($x == 0) echo "<tr>";
			echo td($type);
			if ($x++ == $WIDTH-1) {
				echo "</tr>";
				$x = 0;
			}
		}
	?>
	</table>
</td>

</tr></table>

<? include("template.inc"); ?>
