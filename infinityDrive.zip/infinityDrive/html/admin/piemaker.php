<?php


/*

The Pie chart generator by Ashish Kasturia (http://www.123ashish.com)
Copyright (C) 2003 Ashish Kasturia (ashish at 123ashish.com)


The Pie chart generator is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, 
USA.

*/


class Pie
{
	var $imageWidth = 400;
	var $imageHeight = 400;
	var $pieScale = 0.6;
	var $bgR = 255;
	var $bgG = 255;
	var $bgB = 255;
	var $title = "Pie Chart - 123ashish.com";

	function create($varDesc, $varValues)
	{
		Header("Content-type: image/png");
		$image = ImageCreate($this->imageWidth, $this->imageHeight);

		$pieCenterX = $this->imageWidth/2;
		$pieCenterY = $this->imageHeight/2;

		$bgcolor = ImageColorAllocate($image, $this->bgR, $this->bgG, $this->bgB);

		$white = ImageColorAllocate($image, 255, 255, 255);
		$black = ImageColorAllocate($image, 0, 0, 0);
		ImageFill($image, 0, 0, $bgcolor);

		srand(29454321);   # keep the colors the same every time

		$num = 0;
		foreach($varDesc as $v)
		{
			$r = rand (0, 255);
			$g = rand (0, 255);
			$b = rand (0, 255);

			$sliceColors[$num] = ImageColorAllocate($image, $r, $g, $b);
			$scale = 0.8;
			$sliceColorsDim[$num] = ImageColorAllocate($image, $r*$scale, $g*$scale, $b*$scale);
			$num++;
		}

		// now $num has the number of elements

		// draw the box
		ImageLine($image, 0, 0, $this->imageWidth - 1, 0, $black);
		ImageLine($image, $this->imageWidth - 1, 0, $this->imageWidth - 1, $this->imageHeight - 1, $black);
		ImageLine($image, $this->imageWidth - 1, $this->imageHeight - 1, 0, $this->imageHeight - 1, $black);
		ImageLine($image, 0, $this->imageHeight - 1, 0, 0, $black);


		$total = 0;
		for ($x = 0; $x < $num; $x++)
		{
			$total += $varValues[$x];
		}

		// convert each slice into corresponding percentage of 360-degree circle
		for ($x = 0; $x < $num; $x++)
		{
			$angles[$x] = ($varValues[$x] / $total) * 360;
		}


		for($x = 0; $x < $num; $x++)
		{
			// calculate and draw arc corresponding to each slice
			ImageArc($image, $pieCenterX, $pieCenterY,
				$this->imageWidth * $this->pieScale,
				$this->imageHeight * $this->pieScale, 
				$angle, ($angle + $angles[$x]), $sliceColorsDim[$x]);

			$angle = $angle + $angles[$x];

			$x1 = round($pieCenterX + ($this->imageWidth * $this->pieScale * cos($angle*pi()/180)) / 2);
			$y1 = round($pieCenterY + ($this->imageHeight * $this->pieScale * sin($angle*pi()/180)) / 2);

			// demarcate slice with another line
			ImageLine($image, $pieCenterX, $pieCenterY, $x1, $y1, $sliceColorsDim[$x]);
		}

		// fill in the arcs
		$angle = 0;
		for($x = 0; $x < $num; $x++)
		{
			$x1 = round($pieCenterX +
				($this->imageWidth * $this->pieScale * cos(($angle + $angles[$x] / 2)*pi()/180)) / 4);
			$y1 = round($pieCenterY +
				($this->imageHeight * $this->pieScale * sin(($angle + $angles[$x] / 2)*pi()/180)) / 4);

			ImageFill($image, $x1, $y1, $sliceColors[$x]);

			$angle = $angle + $angles[$x];
		}

		// labels which use lines to point to their slices
		$angle = 0;
		$lineLen = 1.00;
		for($x = 0; $x < $num; $x++)
		{
			// draw a line which radiates out through the center of the slice
			$angle += $angles[$x] / 2;

			$lineLen += 0.20;
			if ($lineLen > 1.5) $lineLen = 1.05;
			$x1 = round($pieCenterX + ($this->imageWidth * $this->pieScale * 0.5 * cos($angle*pi()/180)) / 2);
			$y1 = round($pieCenterY + ($this->imageHeight * $this->pieScale * 0.5 * sin($angle*pi()/180)) / 2);
			$x2 = round($pieCenterX + ($this->imageWidth * $this->pieScale * $lineLen * cos($angle*pi()/180)) / 2);
			$y2 = round($pieCenterY + ($this->imageHeight * $this->pieScale * $lineLen * sin($angle*pi()/180)) / 2);

			ImageLine($image, $x1, $y1, $x2, $y2, $black);

			// place a label at the end of the line
			$text = $varDesc[$x];
			if ($angle > 180) $y2 -= 15;
			if ($angle > 90 && $angle < 270) $x2 -= strlen($text)*7;
			ImageString($image, 3, $x2, $y2, $text, $sliceColors[$x]);

			$angle += $angles[$x] / 2;
		}

		/*
		function format($val) { return sprintf("$%0.0f", $val/100); }

		// put the desc strings
		ImageString($image, 5, $this->imageWidth/2, 60, "Legend", $black);
		for($x = 0; $x < $num; $x++)
		{
			$fl = sprintf("%.2f", $varValues[$x] * 100 / $total);
			$str = $varDesc[$x]." " . format($varValues[$x]) . " (".$fl."%)";
			#$str .= "[" . $angles[$x] . "]";
			ImageString($image, 3	, $this->imageWidth/2, ($x + 5) * 20, $str, $sliceColors[$x]);
		}
		ImageString($image, 3, $this->imageWidth/2, ($x+5)*20, "Total: " . format($total), $black);

		// put the title
		ImageString($image, 5, 20, 20, $this->title, $black);
		*/

		ImagePng($image);
		ImageDestroy($image);

		srand();     # reset to a standard random seed
	}
}

$pie = new Pie;

$width = $_REQUEST['width'];
if (!isset($width)) $width = 400;
$height = $_REQUEST['height'];
if (!isset($height)) $height = 400;
$title = $_REQUEST['title'];
if (!isset($title)) $title = "Untitled";
$desc = $_REQUEST['desc'];
if (!isset($desc)) $desc = "a,b,c";
$values = $_REQUEST['values'];
if (!isset($values)) $values = "1,2,3";

$pie->imageWidth = $width;
$pie->imageHeight = $height;
$pie->title = $title;

$varDesc = explode(",", $desc);
$varValues = explode(",", $values);

$pie->create($varDesc, $varValues);

?>
