<?

	require_once("defs.inc");

	$data = array();
	$dav_folder = local_dav_folder();
	$f = popen("cd $dav_folder ; du -s *", "r");
	while ($line = fgets($f,1024)) 
	{ 
		$line = trim($line);
		$tmp = explode("\t",$line);
		if ($tmp[1] != "CVS")
		{
			# key to sort by size, but ensure uniqueness
			$key = sprintf("%020d", $tmp[0]) . "_" . $tmp[1];
			$data[$key] = $tmp;
		}
	}
	pclose($f);

	# sort in descending order
	krsort($data);
?>
<? require("template.inc"); ?>

<div id="mainheader">
	Disk Usage Stats - <a href=index.php>Main Menu</a>
</div>

<table id="du">
	<tr id="duheader">
		<th>Username</th><th>Disk Usage</th><th>Quota</th>
	</tr>
	<?
		foreach ($data as $d)
		{
			echo "<tr>\n";
			echo td("<a href=account.php?account=$d[1]>$d[1]</a>");
			echo td(prettysize($d[0]));
			echo td(prettysize(1024*1024*6));
			echo "</tr>\n";
		}
	?>
</table>

<? require("template.inc"); ?>
