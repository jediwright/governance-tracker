<? include("template.inc"); ?>
<?
	### determine period
	$month = $_REQUEST['month'];
	$year = $_REQUEST['year'];

	$stamp = time() - 3*24*60*60;
	if (!$month) $month = date("m", $stamp);
	if (!$year) $year = date("Y", $stamp);

	$month = sprintf("%02d", $month);
	$is_current_month = ("$year-$month" == date("Y-m"));
	$prorate = !$is_current_month ? 1 : (date("d") / cal_days_in_month(CAL_GREGORIAN, $month, $year));

	$periods = array("1 month", "3 months", "1 year");
	$period = notnull($_REQUEST['period'], $periods[0]);

	function datesql($field)
	{
		global $month, $year, $period;
		return "$field between date('$year-$month-01') and date('$year-$month-01') + interval '$period' - interval '1 second'";
	}
?>

<form>
<table bgcolor=#e0e0e0 align=center>
	<tr>
		<td>Date:</td>
		<td><?= makeselect("month", array("01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"), $month) ?></td>
		<td><?= makeselect("year", array(2004, 2005, 2006), $year) ?></td>
		<td>Period:</td>
		<td><?= makeselect("period", $periods, $period) ?></td>
		<?
			echo td("");
			$nm = ($month-1 < 1) ? 12 : $month-1;
			$ny = ($month-1 < 1) ? $year-1 : $year;
			echo td("<a href=report-expenses.php?month=$nm&year=$ny>&lt; Prev</a> &nbsp;");
			$nm = ($month+1 > 12) ? 1 : $month+1;
			$ny = ($month+1 > 12) ? $year+1 : $year;
			echo td(" &nbsp; <a href=report-expenses.php?month=$nm&year=$ny>Next &gt;</a>");
		?>
	</tr>
	<tr>
		<th colspan=10><input type=submit name=altered value=Go></td>
	</tr>
</form>

<?
	$sql = datesql("paid_on");

	### calc expenses
	$expenses = select_vertical_assoc("SELECT distinct type,sum(amount) FROM v_expenses WHERE bar is not true AND $sql GROUP BY type");
	if ($ventures{'bar'})
		$bar_amount = select_one("SELECT sum(amount) FROM v_expenses WHERE bar is true AND $sql");
	else
		$bar_amount = 0;

	if ($bar_amount > 0)
		$expenses{'bar'} = $bar_amount;

	$total = 0;
	foreach ($expenses as $type => $amount)
	{
		$amount = money2int($amount);
		if ($type == "office" || $type == "bank")
			$amount *= $prorate;
		$expenses{$type} = $amount;
		$total += $amount;
	}

	arsort($expenses);
?>

<table align=center>
<tr bgcolor=lightblue><th colspan=12><h3>Expenses</h3></th></tr>
<tr valign=top>
	<td>
		<table border=1>
		<?
			foreach ($expenses as $venture => $amount)
			{
				echo "<tr><th>$venture</th>";
				echo td(money($amount));
				$amount = money2int($amount);
				$percent = ($amount / $total) * 100;
				echo td(sprintf("%2d", $percent) . "%");
				echo "</tr>";
			}

			echo "<tr bgcolor=lightgray><th>Total:</th><td colspan=2>" . money($total) . "</td></tr>";
		?>
		</table>
	</td>
	<td>
	<?
		$url = "title=Expenses&";
		$url .= "desc=" . urlencode(join(",", array_keys($expenses))) . "&";
		$url .= "values=" . urlencode(join(",", array_values($expenses))) . "&";

		echo "<img src=\"piemaker.php?$url\" border=1>";
	?>
	</td>
</tr>

</table>

<p>
<hr>
<p>

<table align=center>
<?
	### line item listing of expenses, sorted by venture and then size
	function show_last()
	{
		global $last_type, $total, $type;
		if ($last_type)
			echo "<tr><td align=right colspan=4>Total:</td><td bgcolor=lightgreen>" . money($total) . "</td></tr>";

		$last_type = $type;
		$total = 0;
	}

	$fields = array("name", "paid_on", "method", "description", "amount");
	echo "<tr>";
	foreach ($fields as $f)
		echo "<th>" . ucwords($f) . "</th>";
	echo "</tr>";

	$total = 0;
	$res = sql_query("SELECT * FROM v_expenses WHERE $sql AND bar is not true ORDER BY type,amount DESC");
	while (($row = pg_fetch_array($res)))
	{
		$type = $row{'type'};
		if ($type != $last_type)
		{
			show_last();
			echo "<tr><th colspan=10 bgcolor=#d0d0d0>" . ucwords($type) . "</th></tr>";
		}

		echo "<tr>";
		foreach ($fields as $f)
			echo td($row{$f});
		echo "</tr>";

		$total += money2int($row{'amount'});
	}

	show_last();
?>
</table>

<? include("template.inc"); ?>
