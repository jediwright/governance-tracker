<? require("template.inc"); ?>
<?
	$type = notnull(request("type"), "active");
?>

<div id="mainheader">
	Accounts - <a href=index.php>Main Menu</a>
</div>

<div id=list_header>
<ul>
	<li<?= $type == 'active' ? " id=current" : "" ?>><a href="<?= $_SERVER[PHP_SELF]?>?type=active">Active Accounts</a></li>
	<li<?= $type == 'inactive' ? " id=current" : "" ?>><a href="<?= $_SERVER[PHP_SELF]?>?type=inactive">Inactive Accounts</a></li>
	<li<?= $type == 'beta' ? " id=current" : "" ?>><a href="<?= $_SERVER[PHP_SELF]?>?type=beta">Beta Accounts</a></li>
</ul>
</div>
<br clear=all>

<div id="accountbox">
	<?

	if ($type == "active")
		$where = "active=true AND beta is not true";
	else if ($type == "inactive")
		$where = "active is not true AND beta is not true";
	else if ($type == "beta")
		$where = "beta=true";
	else
		die("bad type");

	$sql = "SELECT *,opened::date as opened_date FROM accounts WHERE $where ORDER BY disk_usage DESC";
	$data = select_all($sql);

	echo "<table id=accounts>\n";
	echo "<tr>
		<th>Username</th>
		<th>Created</th>
		<th>Name</th>
		<th>Company</th>
		<th>Email</th>
		<th>Plan</th>
		<th>Disk Usage</th>
		</tr>\n";
	foreach ($data as $account)
	{
		echo "<tr>";
		echo "<td><a href=account.php?account=$account[account]>$account[account]</a></td>\n";
		echo "<td>$account[opened_date]</td>\n";
		echo td($account['contact_name']);
		echo td($account['company']);
		echo td($account['email']);
		echo "<td>";
		echo $plans[$account[plan_id]][0];
		echo "</td>\n";
		echo td(round($account['disk_usage'] / GB, 1) . " GB");
		echo "</tr>";
	}
	echo "</table>\n";

	?>

	<div id="clear"></div>
</div>

<? require("template.inc"); ?>
