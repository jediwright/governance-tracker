<?
	require_once("defs.inc");

	$sql = "SELECT * FROM accounts WHERE account = " . sql_quote(request("account"));
	$data = select_row($sql);

	if ($_REQUEST[action] == "Edit")
	{
		redirect("account_edit.php?account=$_REQUEST[account]");
	}

	if ($_REQUEST[action] == "Suspend")
	{
		sql_query("UPDATE accounts SET active = false WHERE account = '$_REQUEST[account]'");
		redirect("account.php?account=$_REQUEST[account]");
	}

	if ($_REQUEST[action] == "Reactivate")
	{
		sql_query("UPDATE accounts SET active = true WHERE account = '$_REQUEST[account]'");
		redirect("account.php?account=$_REQUEST[account]");
	}

	if (request("login"))
	{
		login($data['account']);
	}

	if ($data[active] == 't')
	{
		$up_name = 'Active Accounts';
		$up_url = 'accounts.php?active=t';
	}
	else
	{
		$up_name = 'Inactive Accounts';
		$up_url = 'accounts.php?active=f';
	}

	// FIXME - should never need to delete - put in some kind of archive feature instead

	if ($_REQUEST[action] == "Delete")
	{
		$dav_folder = local_dav_folder();
		die("not implemented - dont delete accounts");
		rmdir("$dav_folder/$_REQUEST[account]");
		sql_query("DELETE FROM accounts WHERE account = '$_REQUEST[account]'");
		redirect($up_url);
	}


?>
<? require("template.inc"); ?>

<div id="mainheader">
	Account Detail &lt; <a href=<?= $up_url ?>><?= $up_name ?></a> &lt; <a href=index.php>Main Menu</a>
</div>

<div id=accountbox>
<div id=accounts>

<div style='text-align: right; margin-right: 5em;'>
	<a href="account.php?account=<?= $data['account'] ?>&login=1">log in as this account</a>
</div>

<form>
<input type=hidden name=account value="<?= $_REQUEST[account]?>">
<?

echo "<table>\n";
foreach ($data as $k => $v)
{
	if ($k == "cvv") continue;
	echo "<tr>";
	echo "<th>$k</th>\n";
	echo "<td>$v</td>\n";
	echo "</tr>";
}

$bandwidth = select_row("SELECT sum(bytes_in) + sum(bytes_out) as total, max(period) - min(period) as period FROM bandwidth WHERE account_id = $data[account_id]");

echo "<tr>";
echo "<th>Bandwidth Used</th>\n";
echo "<td>".prettysize($bandwidth[total])."</td>\n";
echo "</tr>";
if ($bandwidth[period] > 0)
{
	echo "<tr>";
	echo "<th>Bandwidth Rate</th>\n";
	echo "<td>". prettysize(round(($bandwidth[total] / $bandwidth[period]))). "/day </td>\n";
	echo "</tr>";
}

$dav_folder = local_dav_folder();
$disk_space = explode("\t",`du -s $dav_folder/$data[account]`);

echo "<tr>";
echo "<th>Disk Space Used</th>\n";
echo "<td>$disk_space[0]K</td>\n";
echo "</tr>";


echo "</table>\n";
?>
<br clear=all>
<input type=submit name=action value="Edit">

<? 
	if ($data[active] == 't') 
	{ 
		echo '<input type=submit name=action value="Suspend" onClick="javascript:confirm(\'Are you sure you want to suspend this account?\')">';
	} 
	else 
	{
		echo '<input type=submit name=action value="Reactivate">';
	}
 ?>

<input type=submit name=action value="Delete" onClick="javascript:confirm('Are you sure you want to delete this account?')">
</form>
</div>
</div>

<? require("template.inc"); ?>
