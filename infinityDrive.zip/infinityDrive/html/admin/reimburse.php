<? $access_required = 35; include("defs.inc"); ?>
<?
	$fields = array("recipient", "amount", "checknum", "date_paid");

	if ($_REQUEST['reim'])
	{
		$params = array();
		foreach ($fields as $k)
			$params[$k] = $_REQUEST[$k];

		sql_insert("reimbursements", $params);
		redirect("reimburse.php?received=1");
	}

	$users = array("adam", "orion");
?>
<? include("template.inc"); ?>
<?
	if ($_REQUEST['received'])
		echo "<h3>Reimbursement Sent</h3>";
?>

<form>
<table cellspacing=0 cellpadding=4 border=0 align=center>
<tr valign=top>
<td>

	<table cellspacing=0 cellpadding=4 border=1>
	<tr><th colspan=2 bgcolor=lightblue>Issue a Reimbursement</th></tr>

	<?
		# then the form
		foreach ($fields as $field)
		{
			$input = $val = null;
			if ($field == "recipient")
			{
				$reim = $users;
				$reim[] = "--";
				$input = makeselect($field, $reim, $_user);
			}
			if ($field == "date_paid")
				$val = date("Y-m-d");

			if (!$input)
				$input = "<input type=text name=$field value=\"$val\">";

			echo "<tr><th>" . ucwords(preg_replace("/_/", " ", $field)) . "</th><td>$input</td></tr>";
		}
	?>
	<tr><th colspan=2><input name=reim type=submit value="Submit"></th></tr>

	</table>
</td>
<td>
<?
	# first show outstanding owed amounts
	$reims = select_vertical_assoc("SELECT recipient,sum(amount) FROM reimbursements GROUP BY recipient");
	$to_reim = select_vertical_assoc("SELECT distinct reimburse_to,sum(amount) FROM expenses GROUP BY reimburse_to");

	echo "<table width=100% cellspacing=0 cellpadding=3 border=1>";
	foreach ($users as $u)
	{
		$diff = money2int($to_reim{$u}) - money2int($reims{$u});
		if ($diff == 0) continue;
		echo "<tr bgcolor=lightgreen><th>$u</th><td>" . money($diff) . "</td></tr>";

		echo "<tr><td colspan=2><table width=100% cellspacing=0 cellpadding=3 border=1>";
		$res =  sql_query("SELECT * FROM expenses NATURAL JOIN expense_recipients WHERE paid_on>current_date-30 AND reimburse_to='$u' ORDER BY paid_on DESC LIMIT 10");
		for ($i = 0; $i < pg_num_rows($res); $i++)
		{
			$row = pg_fetch_array($res, $i);
			echo "<td>" . $row{'name'} . "</td><td>" . $row{'description'} . "</td><td>" . $row{'amount'} . "</td><td>" . $row{'paid_on'} . "</td></tr>";
		}
		echo "</table></td></tr>";
	}
	echo "</table>";
?>

</td>
</tr>
</table>
</form>

<? include("template.inc"); ?>
