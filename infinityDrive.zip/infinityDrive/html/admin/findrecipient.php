<? include("defs.inc"); ?>
<?
	$search = $_REQUEST['search'];
	if ($search)
		$onload = "ff.use.focus();";
	else
		$onload = "ff.pattern.focus();";
?>
<?  include("template.inc"); ?>

<?  if (!$search) { ?>
	<br>
	<form name=ff>
	<table cellspacing=0 cellpadding=4 border=1 align=center>
	<tr><th colspan=2>Find an Expense Recipient</th></tr>
	<tr>
		<th>Enter a name or type:</th>
		<td><input type=text name=pattern size=30> <i>(partial match ok)</i></td>
	</tr>
	<tr><th align=right colspan=2><input name=search type=submit value="Next >"></th></tr>
	</table>
	</form>
<? } else { ?>

	<br>
	<form name=ff action=expense.php>
	<table cellspacing=0 cellpadding=4 border=1 align=center>
	<tr><th colspan=4>Select a Recipient</th></tr>
	<?
		$fields = array("recipient_id", "name", "type", "use");
		echo fieldheaders($fields);

		$pattern = sql_quote("%" . strtolower($_REQUEST['pattern']) . "%");
		$recips = select_all("SELECT * FROM expense_recipients WHERE lower(name) like $pattern OR lower(type) like $pattern");
		foreach ($recips as $r)
		{
			echo "<tr>";
			$id = $r{'recipient_id'};
			if (!$first) $first = $id;
			echo td($id);
			echo td("<a href=showrecipient.php?id=$id>" . $r{'name'} . "</a>");
			echo td($r{'type'});
			echo td("<a href=expense.php?id=$id>use this one</a>");
			echo "</tr>";
		}
	?>
	<tr>
		<td colspan=2 align=left>
			<a href=recipient.php>add new</a>
		</td>
		<td colspan=2 align=right>
			<? if ($first) { ?>
			<input type=hidden name=id value=<?= $first ?>>
			<input type=submit name=use value="use the first one">
			<? } ?>
		</td>
	</tr>
	</table>
	</form>

<? } ?>
<? include("template.inc"); ?>
