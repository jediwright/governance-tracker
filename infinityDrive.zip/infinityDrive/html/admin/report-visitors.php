<? include("template.inc"); ?>
<?
	### determine period
	$month = $_REQUEST['month'];
	$year = $_REQUEST['year'];

	if (!$month) $month = "01";
	if (!$year) $year = date("Y");

	$month = sprintf("%02d", $month);
	$is_current_month = ("$year-$month" == date("Y-m"));
	$prorate = !$is_current_month ? 1 : (date("d") / cal_days_in_month(CAL_GREGORIAN, $month, $year));

	$periods = array("1 month", "3 months", "1 year");
	$period = notnull($_REQUEST['period'], $periods[2]);

	function datesql($field)
	{
		global $month, $year, $period;
		return "$field between date('$year-$month-01') and date('$year-$month-01') + interval '$period' - interval '1 second'";
	}
?>

<form>
<table bgcolor=#e0e0e0 align=center>
	<tr>
		<td>Date:</td>
		<td><?= makeselect("month", array("01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"), $month) ?></td>
		<td><?= makeselect("year", array(2004, 2005, 2006), $year) ?></td>
		<td>Period:</td>
		<td><?= makeselect("period", $periods, $period) ?></td>
		<?
			echo td("");
			$nm = ($month-1 < 1) ? 12 : $month-1;
			$ny = ($month-1 < 1) ? $year-1 : $year;
			echo td("<a href=report-expenses.php?month=$nm&year=$ny>&lt; Prev</a> &nbsp;");
			$nm = ($month+1 > 12) ? 1 : $month+1;
			$ny = ($month+1 > 12) ? $year+1 : $year;
			echo td(" &nbsp; <a href=report-expenses.php?month=$nm&year=$ny>Next &gt;</a>");
		?>
	</tr>
	<tr>
		<th colspan=10><input type=submit name=altered value=Go></td>
	</tr>
</table>
</form>

<table id="visitorreport">
<tr><th>Keyword</th><th>Count</th><th>Signups</th><th>Ratio</th></tr>
<?
	$visitors = select_all("SELECT keywords,count(*),sum(case when account_id is null then 0 else 1 end) as accounts FROM visitors JOIN keywords USING (keyword_id) LEFT JOIN accounts USING (visitor_id) WHERE " . datesql("first_visit") . " GROUP BY keywords ORDER BY count DESC");
	foreach ($visitors as $v)
	{
		echo "<tr>";
		echo td($v['keywords']);
		echo td($v['count']);
		echo td($v['accounts']);

		$ratio = $v['accounts'] / $v['count'];
		echo td(round($ratio * 100, 1) . "%");

		echo "</tr>";
	}
?>
</table>

<? include("template.inc"); ?>
