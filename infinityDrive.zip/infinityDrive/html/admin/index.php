<? require("template.inc"); ?>

<div id="mainheader">
	infinityDrive Admin - Control Pannel
</div>

<div id="mainmenuitem">
	<h1><a href="accounts.php">Accounts</a></h1>
	<p>View and update accounts.</p>
</div>

<div id="mainmenuitem">
	<h1><a href="bandwidth.php">Bandwidth</a></h1>
	<p>View bandwidth usage information.</p>
</div>

<div id="mainmenuitem">
	<h1><a href="du.php">DU</a></h1>
	<p>View disk usage stats</p>
</div>

<div id="mainmenuitem">
	<h1><a href="billing.php">Billing</a></h1>
	<p>View billing stats / company income.</p>
</div>

<div id="mainmenuitem">
	<h1>Expenses</h1>
	<a href="findrecipient.php">Enter new expense</a><br>
	<a href="report-expenses.php">Expense report</a><br>
	<a href="reimburse.php">Reimbursement</a>
</div>

<div id="mainmenuitem">
	<h1>Reports</h1>
	<a href="report-visitors.php">Visitors</a><br>
</div>

<div id="clear"></div>

<? require("template.inc"); ?>
