<? include("defs.inc"); ?>
<?
?>
<? include("template.inc"); ?>

<div style='width: 20em; margin: auto; font-size: 125%;'>

<div>
	<?
		$invoices = select_row("SELECT count(*),sum(invoice_amount) FROM invoices WHERE closed=false");
	?>
	Open invoices: <?= $invoices['count'] ?> totaling <?= money($invoices['sum']) ?>
</div>

<div>
	<?
		$revenue = select_row("SELECT count(*),sum(invoice_amount) FROM invoices WHERE closed=true");
	?>
	Collected payments: <?= $revenue['count'] ?> totaling <?= money($revenue['sum']) ?>
</div>

</div>

<? include("template.inc"); ?>
