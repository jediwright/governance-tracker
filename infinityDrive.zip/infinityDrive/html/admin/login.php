<? $no_login = 1; include("defs.inc"); ?>
<?
	if ($_REQUEST['login'])
	{
		$user = trim(strtolower($_REQUEST['user']));
		$password = $_REQUEST['password'];

		$good = (($user == "adam" && $password == "#$9zdu1l") 
				|| ($user == "orion" && $password == "STx93noor"));
		if (!$good)
			redirect("login.php");

		$_SESSION['user'] = $user;
		redirect("index.php");
	}
?>
<html>
<body>

<form method=post>

<table align=center>
	<tr><td>User:</td><td><input type=text name=user></td>
	<tr><td>Password:</td><td><input type=password name=password></td></tr>
	<tr><td colspan=10 align=center><input type=submit name=login value="Login"></td></tr>
</table>

</form>

</body>
</html>
