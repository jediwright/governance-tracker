<? include("template.inc"); ?>

<div id="maincolumn">
	
	<div id="leftsub">
		<h1>How it works</h1>
		<img src="images/shots/xpbrowse.png" style="float: right; margin-left: 1em; margin-right: 1em;" />
		<p>
		infinityDrive is remote storage service which can be accessed 
		through your file manager just like a local drive.  You can access
		infinityDrive this way with most modern operating systems including Mac OS
		X, Windows 98/2000/ME/XP, and Linux.  In most cases NO software install is
		necessary.  You will be up and running minutes after creating your account.
		</p>
		<p>
		You can access infinityDrive anywhere with a network connection.
		Share files between home and work, access with your laptop from a Wifi
		hotspot, or log in from a distant hotel room.  With infinityDrive, your data
		is always with you.
		</p>
		<p>
		The web management interface works with any computer equiped with a
		browser, so you can even access infinityDrive in places like a public
		library terminal, a print shop, or at a friend's house.
		</p>
		<img src="images/shots/osxexplore.png" style="float: right; margin-left: 1em; margin-right: 1em; margin-top: 1em;" />
		<p>
		Your local drive is vulnerable to viruses and physical damage, putting your
		important business or personal files at risk.  infinityDrive runs on our high-end,
		multiple-redundant servers and will never lose any data.
		</p>
		<p>
		Storage availability is determined according to your <a
		href=plans.php>plan</a>.  Grow your storage instantly whenever you need,
		without disrupting your existing files.
		</p>
		<div id="clear"></div>
	</div>
</div>

<?= showrightcol() ?>

<div id="clear"></div>

<? include("template.inc"); ?>
