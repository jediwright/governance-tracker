<?
	$no_login = 1;
	require_once("defs.inc");

	$message = null;
	$account = select_row("SELECT * FROM accounts JOIN recovery USING (account_id) WHERE recovery_hash = '".addslashes($_REQUEST[hash])."' AND recovery_completed IS FALSE AND recovery_time > current_date - interval '1 days'");

	if ($account && $_REQUEST['password1'])
	{
		$password1 = trim($_REQUEST['password1']);
		$password2 = trim($_REQUEST['password2']);
		if ($password1 == $password2)
		{
			$password = $password1;
			if (!valid_password($password))
				$message = "The password you supplied is invalid.  $password_rule";
			else
			{
				$data = array();
				$data[password] = $password;
				$data[hash] = md5($password);

				sql_query("BEGIN");
				sql_update("users", array("password" => $password, "hash" => md5($password)), "account_id=$account[account_id] AND username=" . sql_quote($account['account']));
				sql_update("recovery", array("recovery_completed" => "true"), "recovery_id=$account[recovery_id]");
				sql_query("COMMIT");
				login($account[account]);
			}
		}
		else $message = "Passwords do not match";
	}

	if ($account === null and $message === null) $error = "Bad or Expired Password Recovery Link";

	include("template.inc");
?>


<?
	if ($error) 
		echo "<div class=errorbox>$error</div>";
	else
	{
?>
<form name="ff" method="post">
<input type=hidden name=hash value="<?=htmlspecialchars($_REQUEST[hash])?>">
<div id="recoverybox">
	<div id="recoveryheader">Resetting Password For <?= $account[account] ?></div>
	<?  
		if ($message)
		{ 
			echo "<div class=errorbox>$message</div>";
		} 
	?>
	<table id="recoverytable">
		<tr><td align=right>Select a new password:</td><td><input type="password" name="password1"></td></tr>
		<tr><td align=right>Retype the password:</td><td><input type="password" name="password2"></td></tr>
		<tr><td align="center" colspan="2"><input id="loginbutton" type="submit" name="login" value="Reset Password"></td></tr>
	</table>
</div>

</form>

<? 
	}

	include("template.inc"); 
?>
