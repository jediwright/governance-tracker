<? include("template.inc"); ?>

<h1>Signup Complete</h1>

<?= img("freeway.jpg", "style='float: right; margin-left: 1em; margin-right: 1em; border: 1px solid #606060;'") ?>

<p>Thank you!  Your infinityDrive user has been created, and you are now logged into the web portion of infinityDrive.  Setup instructions for the non-web portion follow.</p>

<table id="welcomeinfo">
<tr><td colspan="2" style='text-align: center; color: black;'>Web Login</td></tr>
<tr><th>URL</td><td><a href="<?= $secure_url ?>"><?= $secure_url ?></a></td></tr>
<tr><th>Login</td><td><?= $_user[username] ?></td></tr>
</table>

<table id="welcomeinfo">
<tr><td colspan="2" style='text-align: center; color: black;'>infinityDrive Mount</td></tr>
<tr><th>URL</td><td><?= davurl() ?></td></tr>
<tr><th>Username</td><td><?= $_user[username] ?></td></tr>
</table>

<div id="lookslike">
<?
	$instruct = array(
		"windows" => "Windows",
		"macosx" => "Mac OS X",
		"kde" => "KDE",
		"gnome" => "GNOME",
		"macos9" => "Mac OS 9",
		"cmdline" => "UNIX command line",
	);
	$images = array(
		"macosx" => "mac",
		"windows" => "windows",
		"kde" => "tux",
	);

	$agent = $_SERVER['HTTP_USER_AGENT'];
	if (strstr($agent, "Safari"))
		$guess = "macosx";
	else if (strstr($agent, "Linux") || strstr($agent, "Konqueror"))
		$guess = "kde";
	else if (strstr($agent, "BSD"))
		$guess = "cmdline";
	else
		$guess = "windows";

	echo "<p>It looks like you are using " . knowledgedoc("setup-" . $guess, $instruct{$guess}) . ".  Or, choose from the list below.</p>";

	echo "<div id='setupbox'>";
		echo "<h3>infinityDrive Setup Instructions</h3>";
		foreach ($instruct as $page => $name)
		{
			echo "<div id=\"instruct\">";
			$style = "float: left; margin-right: 0.5em; width: 30px; border: 0;";
			if ($images[$page])
				echo knowledgedoc("setup-$page", img($images[$page] . ".jpg", "style='$style'"));
			else if ($page != "gnome")
				echo "<div style='$style'>&nbsp;</div>";
			echo knowledgedoc("setup-$page", $name);
			echo "</div>";
			if ($page != "kde")
				echo "<div id=clear></div>";
		}
	echo "</div>";
?>
</div>

<? include("template.inc"); ?>
