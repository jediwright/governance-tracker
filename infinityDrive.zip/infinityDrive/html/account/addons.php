<? require_once("defs.inc"); ?>
<?
	$plan = $plans[$account['plan_id']];
	$base_quota = $plan[2]; $base_users = $plan[3]; $base_shares = $plan[4];

	if (request("update"))
	{
		$offenders = array();
		foreach (array("quota", "users", "shares") as $field)
		{
			$val = notnull(request_numeric("addon_" . $field), 0);
			if ($val < 0 || $val > 3000)
				$offenders[] = $field;

			$params[$field] = $val;
		}
		if (count($offenders))
			redirect("addons.php?error=1&offenders=" . join(",", $offenders));

		$params['bill'] = $plan[1];
		$params['bill'] += ($params['quota'] + $params['users'] + $params['shares']) * 3;

		$params['quota'] += $base_quota;
		$params['users'] += $base_users;
		$params['shares'] += $base_shares;

		sql_update("accounts", $params, "account_id=" . $account['account_id']);

		# in case they were buying some more space to fix their over quota problem
		$account = select_row("SELECT * FROM accounts WHERE account_id=" . $account['account_id']);
		update_over_quota($account);

		redirect("index.php");
	}

	$addon_quota = max(0, $account['quota'] - $base_quota);
	$addon_users = max(0, $account['users'] - $base_users);
	$addon_shares = max(0, $account['shares'] - $base_shares);

	$onload = "update_price()";
?>
<? include("template.inc"); ?>

<div id="mainheader">
	infinityDrive Account - Purchase Add-Ons
</div>

<?
	$offenders = request("offenders");
	if ($offenders)
	{
		$offenders = explode(",", $offenders);
		$msg = "One or more of the fields was not entered properly.  Please enter numbers only.";
		echo "<div class=errorbox>" . $msg . "</div>";
	}
?>

<form name="ff">
<div id="addonsbox">
	<table id="addons">
	<tr>
		<th></th>
		<th>Disk Space</th>
		<? if ($account['plan_id'] > 0) { ?>
			<th>Users</th>
			<th>Shares</th>
		<? } ?>
		<th>Monthly Price</th>
	</tr>
	<tr>
	<?
		echo th($plan[0] . " Plan:");
		echo td($base_quota . " GB");
		if ($account['plan_id'] > 0) {
			echo td($base_users);
			echo td($base_shares);
		}
		echo td(money($plan[1]));
	?>
	</tr>
	<tr>
		<th>Add to Quota:</td>
		<td><input type="text" name="addon_quota" value="<?= $addon_quota ?>" size="5" onBlur="update_quota()">&nbsp; GB</td>
		<? if ($account['plan_id'] > 0) { ?>
			<td></td>
			<td></td>
		<? } ?>
		<td id="quota_price">0</td>
	</tr>
	<? if ($account['plan_id'] > 0) { ?>
		<tr>
			<th>Add-on Users:</td>
			<td></td>
			<td><input type="text" name="addon_users" value="<?= $addon_users ?>" size="5" onBlur="update_users()"></td>
			<td></td>
			<td id="users_price">0</td>
		</tr>
		<tr>
			<th>Add-on Shares:</td>
			<td></td>
			<td></td>
			<td><input type="text" name="addon_shares" value="<?= $addon_shares ?>" size="5" onBlur="update_shares()"></td>
			<td id="shares_price">0</td>
		</tr>
	<? } else { // keep our javascript from breaking ?>
		<input type="hidden" name="addon_users" value="0">
		<input type="hidden" name="addon_shares" value="0">
	<? } ?>
	<tr>
		<th>Totals:</th>
		<td id="quota_total"><?= $account['quota'] ?> GB</td>
		<? if ($account['plan_id'] > 0) { ?>
			<td id="users_total"><?= $account['users'] ?></td>
			<td id="shares_total"><?= $account['shares'] ?></td>
		<? } ?>
		<td id="total">0</td>
	</tr>
	</table>

	<script language="javascript">
		function money(num)
		{
			num = num.toString();
			if (isNaN(num)) num = "0";
			sign = (num == (num = Math.abs(num)));
			num = Math.round(num*100);
			cents = num%100;
			num = Math.floor(num/100).toString();
			if(cents<10) cents = "0" + cents;	
			return '$' + (((sign)?'':'-') + num + '.' + cents);
		}

		function update_quota()
		{
			var quota = parseInt(document.ff.addon_quota.value) + <?= $base_quota ?>;
			var total = document.getElementById("quota_total");
			total.innerHTML = quota + ' GB';
			update_price();
		}

		function update_users()
		{
			var users = parseInt(document.ff.addon_users.value) + <?= $base_users ?>;
			var total = document.getElementById("users_total");
			total.innerHTML = users;
			update_price();
		}

		function update_shares()
		{
			var shares = parseInt(document.ff.addon_shares.value) + <?= $base_shares ?>;
			var total = document.getElementById("shares_total");
			total.innerHTML = shares;
			update_price();
		}

		var base_price = <?= $plan[1] ?>;
		function update_price()
		{
			var quota_price = parseInt(document.ff.addon_quota.value) * 3;
			var users_price = parseInt(document.ff.addon_users.value) * 3;
			var shares_price = parseInt(document.ff.addon_shares.value) * 3;

			document.getElementById("quota_price").innerHTML = money(quota_price);
			<? if ($account['plan_id'] > 0) { ?>
				document.getElementById("users_price").innerHTML = money(users_price);
				document.getElementById("shares_price").innerHTML = money(shares_price);
			<? } ?>

			var total = document.getElementById("total");
			total.innerHTML = money(base_price + quota_price + users_price + shares_price);
		}
	</script>

	<div id="addons_next">
		<input type="submit" name="update" value="Save Changes">
	</div>
</div>
</form>

<? include("template.inc"); ?>
