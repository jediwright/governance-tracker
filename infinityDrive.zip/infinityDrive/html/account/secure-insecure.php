<? include("template.inc"); ?>

<div id="leftcolumn">
	
	<div id="leftsub2">
		<div id="clear"></div>
		<h1>Secure vs. Insecure</h1>

		<p> Your infinityDrive can be accessed in secure mode or insecure mode.  There are advantage and disadvantages to both modes.  If your infinityDrive URL starts with "http://" you are using an insecure infinityDrive.  If it begins with "https://" you are using a secure infinity drive.</p>

		<p> The secure infinityDrive prevents people on your network at your ISP from seeing what data you are passing back and forth to your infinityDrive and also protects your login and password from being stolen.  InfinityDrive does this by using the HTTPS protocol which uses the industry standard SSL encryption.  Use a secure infinityDrive whenever you can to safeguard your data. </p>

		<p>  The insecure infinityDrive is much faster as it does not have to negotiate complicated SSL encryption codes.  It is also available on more platforms than secure infinityDrive.  If you trust everyone on your local network to not steal your infinityDrive login and password, and you either need the extra speed or simply can not use a secure infinityDrive, you can make use of an insecure infinityDrive.  This is not recommended.  
		</p>

	</div>
</div>

<div id="clear"></div>

<? include("template.inc"); ?>
