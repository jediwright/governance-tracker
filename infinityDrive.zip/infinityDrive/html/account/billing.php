<? require_once("defs.inc"); ?>
<?
	$fields = array("cc", "exp", "billing_name", "address", "city", "state", "zip");
	$bool_fields = array("invoice_email");
	$params = request_to_params($fields, $bool_fields);

	if (request("update"))
	{
		# if they didn't change the cc value (i.e. it is the obfuscated one), then
		# leave it alone
		if ($params['cc'] == obfuscate_cc($account['cc']))
			unset($params['cc']);
		else
		{
			# validate cc
			if (!check_mod10($params['cc']))
				$error = "ccinvalid";
			if (!accept_cardtype($params['cc']))
				$error = "dontaccept";
		}

		# validate expiration
		preg_match("/^(\d\d)\/?(\d\d)$/", $params['exp'], $matches);
		$mon = $matches[1];
		$year = $matches[2];
		if (strlen($mon) != 2 || !is_numeric($mon) || $mon < 1 || $mon > 12)
			$error = "dateinvalid";
		if (strlen($year) != 2 || !is_numeric($year) || $year < date("y") || $year > date("y")+12)
			$error = "dateinvalid";
		$params['exp'] = $mon . $year;

		if ($error) redirect("billing.php?error=$error&edit=1&" . http_build_query($params));

		sql_update("accounts", $params, "account_id=" . $account['account_id']);
		redirect("billing.php");
	}

	$edit = request("edit");

	function obfuscate_cc($cc)
	{
		return "xxxxxxx" . substr($cc, strlen($cc)-4);
	}

	function field($name, $size=20, $note=null, $type="input")
	{
		global $account, $params, $edit, $offenders;

		if ($edit)
			$val = notnull($params[$name], $account[$name]);
		else
			$val = $account[$name];

		if ($name == "cc") {
			if ($edit)
				$val = obfuscate_cc($val);
			else
				$val = cardtype($val) . " " . obfuscate_cc($val);
		}

		if ($name == "exp" && preg_match("/^\d{4}$/", $val))
			$val = substr($val, 0, 2) . "/" . substr($val, 2);

		if ($offenders && in_array($name, $offenders))
			$error = " class=errorfield";

		if (!$edit)
		{
			if ($type == "checkbox")
				$val = ($val == 't') ? "X" : "";
			return $val;
		}

		if ($note) $note = " <i>$note</i>";

		if ($type == "checkbox")
			return makecheckbox($name, substr($val, 0, 1));

		return "<input type=text name=$name size=$size maxlength=$size value=\"$val\"$error>$note";
	}
?>
<? include("template.inc"); ?>

<div id="mainheader">
	infinityDrive Account - Billing
</div>

<?
	$error = request("error");
	if ($error)
	{
		$error_msgs = array(
			"ccinvalid" => "That card number is not valid, check it for typos.",
			"dateinvalid" => "That is not a valid expiration date.  Please enter it in the format MM/YY and make sure the card is not expired.",
			"dontaccept" => "Sorry, but we only accept Visa, Mastercard, or American Express at this time."
		);
		echo "<div class=errorbox>" . $error_msgs[$error] . "</div>";
		$offenders = $error == "dateinvalid" ? array("exp") : array("cc");
	}
?>

<form>
<div id="profilebox">
	<table id="profileinfo">
	<tr><th>Plan:</th><td><?= $account['plan'] ?> <small><a href="updateplan.php">[upgrade]</a> [<a href="addons.php">addons]</a></small></td></tr>
	<tr><th>Monthly Statement Fee:</th><td>$<?= $account['bill'] ?></td></tr>
	<tr><th>Credit Card:</th><td><?= field("cc", 16, "Visa, MC, or AmEx") ?></td></tr>
	<tr><th>Expires:</th><td><?= field("exp", 5, "MM/YY") ?></td></tr>
	<tr><th>Name on Card:</th><td><?= field("billing_name", 40) ?></td></tr>
	<tr><th>Address:</th><td><?= field("address", 40) ?></td></tr>
	<tr><th>City:</th><td><?= field("city", 30) ?></td></tr>
	<tr><th>State or Providence:</th><td><?= field("state", 10) ?></td></tr>
	<tr><th>Zip or Postal code:</th><td><?= field("zip", 10) ?></td></tr>
	<tr><th>Send email invoices:</th><td><?= field("invoice_email", 0, null, "checkbox") ?></td></tr>
	</table>

	<div id="editprofile">
		<? if ($edit) { ?>
			<input type=submit name=update value="Update">
		<? } else { ?>
			<a href="billing.php?edit=1">Edit this information</a>

			<span style='margin-left: 9em; margin-right: 1em; font-size: 75%'>
				<a href="cancel.php">Cancel account</a>
			</span>
		<? } ?>
	</div>
</div>
</form>

<div id="profilebox">
	<p>
	<?
		$invoices = select_all("SELECT * FROM invoices WHERE account_id=" . $account['account_id'] . " ORDER BY invoice_date DESC");

		if (count($invoices) < 1)
		{
			$daysleft = select_one("SELECT extract(epoch from now() - created)/(24*60*60) FROM v_users WHERE user_id=" . sql_quote($account{'user_id'}));
			$daysleft = 30 - floor($daysleft);

			# until we get billing working, just say this FIXME
			$daysleft = max(1, $daysleft);

			echo "You have " . plural($daysleft, "day") . " remaining on your free trial.";
		}
		else
			echo "Your next billing cycle will occur on " . $account['next_billing'] . ".";
	?>
	</p>

	<? if (count($invoices) > 0) { ?>
		<table id="invoices">
		<tr>
			<th>Number</th>
			<th>Date</th>
			<th>Amount</th>
			<th>Status</th>
		</tr>
		<?
			foreach ($invoices as $invoice)
			{
				echo "<tr>";
				echo td("<a href=\"invoice.php?id=" . $invoice['invoice_id'] . "\">" . makeinvoicenum($invoice['invoice_id']) . "</a>");
				echo td($invoice['invoice_date']);
				echo td(money($invoice['invoice_amount']));
				echo td($invoice['closed'] == 't' ? "Paid" : "Awaiting payment");
				echo "</tr>";
			}
		?>
		</table>
	<? } ?>
</div>

<div id="profilelink">
	<a href="profile.php">Profile</a>
</div>

<? include("template.inc"); ?>
