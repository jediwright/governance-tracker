<? require_once("defs.inc"); ?>
<?
	$fields = array("plan_id");
	$params = request_to_params($fields);

	if (request("update"))
	{
		$old_shares = $account['shares'];

		sql_query("BEGIN");

		sql_update("accounts", array("plan_id" => $params[plan_id]), "account_id=" . $account['account_id']);
		update_account_data($account['account_id']);
		$account = select_row("SELECT * FROM accounts WHERE account_id=" . $account['account_id']);

		if (($error = verify_account_resources($account['account_id'])) === TRUE)
		{
			# if they just upgrade from a plan without shares to one with,
			# migrate all the files in their home folder to a new one called "Public".
			if ($old_shares < 2 && $account['shares'] >= 2)
			{
				$params = array(
					"share" => "Public",
					"description" => "Default folder.",
					"account_id" => $account['account_id']);
				$share_id = sql_insert("shares", $params);

				$src = share_local_path($share_id);
				$dst = $src . "/Public";
				if (file_exists($dst))
					rename($dst, $dst . ".old");
				mkdir($dst);
				move_all($src, $dst);
			}

			# if they are downgrading, destroy their single share; we don't move the files since
			# there's no need (the on-disk share just becomes an ordinary directory)
			if ($old_shares > 1 && $account['shares'] <= 1)
				sql_delete("shares", "account_id=" . $account['account_id']);

			update_over_quota($account);

			sql_query("COMMIT");
			redirect("profile.php");
		}
		else
		{
			sql_query("ROLLBACK");
			redirect("updateplan.php?error=$error");
		}
	}

?>
<? include("template.inc"); ?>

<div id="mainheader">
	infinityDrive Account - Update Plan
</div>

<?
	$error = request("error");
	if ($error)
	{
		$error_msgs = array(
			"toomanyusers" => "You currently have too many users.  Delete some users before signing up for this plan.",
			"toomanyshares" => "You currently have too many shares.  Delete some of your shares before signing up for this plan.",
			"overquota" => "You currently are using too much space for this plan.  Delete some of your files and try again."
		);
		echo "<div class=errorbox>" . $error_msgs[$error] . "</div>";
		$offenders = $error == "dateinvalid" ? array("exp") : array("cc");
	}
?>

<form>
<div id="planbox">
	<table id="planinfo">
	<tr>
		<td colspan=2></td>
		<th>Monthly Fee</th>
		<th>Quota</th>
		<th>Users</th>
		<th>Shares</th>
	<?
		$plan_id = 0;
		foreach ($plans as $p)
		{
			if ($account[plan_id] == $plan_id)
			{
				echo "<tr id=selectedplan>";
				echo "<td>$p[0]</td>";
				echo "<td><input name=plan_id type=radio value=$plan_id checked></td>";
			}
			else
			{
				echo "<tr>";
				echo "<th>$p[0]</th>";
				echo "<td><input name=plan_id type=radio value=$plan_id></td>";
			}
			echo "<td>".money($p[1])."</td>";
			echo "<td>$p[2] Gigs</td>";
			echo "<td>$p[3]</td>";
			echo "<td>$p[4]</td>";
			echo "</tr>";
			$plan_id++;
		}
	?>
	</table>

	<div id="editplan">
			<input type=submit name=update value="Update">
	</div>
</div>
</form>

<? if ($account['plan_id'] > 0) { ?>
	<div id="purchaseaddons">
		<a href="addons.php">Purchase add-ons ala carte</a>
	</div>
<? } ?>

<? include("template.inc"); ?>
