<?
	require_once("defs.inc");
	logout();
	redirect("login.php");
?>
