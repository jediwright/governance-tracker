<? require_once("defs.inc"); ?>
<?
	if (request("invite"))
	{
		$email = clean_email(request("email"));
		$share_id = request_numeric("share_id");
		if (!$share_id) error("no share id");
		$share = get_share_byid($share_id);
		if (!$share) error("no share");

		// Two types of invitations: an existing user, or a new one.
		$user_id = select_one("SELECT user_id FROM users WHERE email=" . sql_quote($email));

		if ($user_id)
		{
			// Give immediate access (fixme)
			$p = array(
				"share_id" => $share[share_id],
				"user_id" => $user_id,
				"read" => true,
				"write" => true
			);
			sql_insert("share_permissions", $p);
		}
		else
		{
			/// Create the invitation
			// hash has to be long enough to be secure, short enough that it is easy to cut and paste
			$seed = rand() . $email . time() . "-" . $share[share_id] . "-" . getmypid();
			$hash = substr(sha1($seed), 5, 20);
			$p = array(
				"hash" => $hash,
				"email" => $email,
				"share_id" => $share[share_id],
			);
			sql_insert("invitations", $p);

			/// Send the email
			$to = $email;
			$subject = $_user[full_name] . " invites you to share: " . $share[share];
			$from = "infinityDrive <info@infinitydrive.net>";  // idea: change this to be from the inviting user's email
			$body =
$_user[full_name] . " has invited you to gain access to their infinityDrive share titled \"{$share[share]}\".

To access the files it contains, you will need to create an infinityDrive account.  It's quick and completely free.  Sign up by going here:

https://www.infinitydrive.net/signup.php?invitation=$hash
";

			mail($to, $subject, $body, "From: $from");
		}

		redirect("shareedit.php", array("id" => $share[share_id]));
	}
?>
