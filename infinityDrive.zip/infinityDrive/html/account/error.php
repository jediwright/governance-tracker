<? include("template.inc"); ?>

<div id="mainheader">
	infinityDrive Account - Error
</div>

<div id="errorbox">

	<h1>Oops</h1>
	<p>We're sorry, an error has occured processing your request.  The error message is:</p>
	<div id="errormsg"><?= notnull($MSG, "No error specified") ?></div>
	<p>An email has been sent to our site admin to take a look at the issue.  If you need assistance please <a href=support.php>contact us.</a></p>

</div>

<? include("template.inc"); ?>
