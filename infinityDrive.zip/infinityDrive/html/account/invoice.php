<? require_once("defs.inc"); ?>
<?
	$id = request_numeric("id");
	if (!$id) error("No invoice specified");

	$invoice = select_row("SELECT * FROM invoices NATURAL JOIN accounts WHERE invoice_id=$id");
	if (!$invoice) error("No invoice specified");

	$payment = select_row("SELECT * FROM payments WHERE invoice_id=$id");

	$invoicenum = makeinvoicenum($id);
	$plan = $plans[$invoice['plan_id']][0];

	$cc = notblank($payment['cc_type'] . $payment['cc_last4'], $invoice['cc']);
?>
<html>
<head>
	<title>infinityDrive Invoice <?= $invoicenum ?></title>
	<style type="text/css">
		#wrapper {
			width: 50em;
		}
		#logo {
			float: left;
			margin-right: 3em;
		}
		#ouraddr {
			float: left;
			margin-left: 3em;
			margin-right: 10em;
		}
		#theiraddr {
			float: left;
			margin-right: 3em;
		}
		#invoicedata {
			float: left;
			margin-left: 5em;
		}
		.clear {
			clear: both;
		}
		#items {
			width: 40em;
			margin-left: auto;
			margin-right: auto;
		}
		#items td, th {
			border: 1px solid black;
			padding: 0.3em 0.6em 0.3em 0.6em;
		}
		#footer {
			margin-left: 3em;
		}
		@media print { .noprint { display: none; } }
		#returnlink {
			text-align: center;
		}
	</style>
</head>
<body>

<div id="wrapper">

<div id="logo">
	<img src="<?= $IMG_DIR ?>logo.jpg">
</div>

<div id="invoicedata">
	Invoice Number: <?= $invoicenum ?><br>
	Date: <?= $invoice['invoice_date'] ?>
</div>

<hr class="clear">

<div id="ouraddr">
infinityDrive Corporation<br>
<?= $ADDRESS[0] ?><br>
<?= $ADDRESS[1] ?><br>
<?= $PHONE ?><br>
<?= $EMAIL ?>
</div>

<div id="theiraddr">
Bill to:<br>
<?= $invoice['company'] ?>
<?= $invoice['company'] ? "<br>Attn: " : ""?>
<?= $invoice['billing_name'] ?><br>
<?= $invoice['address'] ?><br>
<?= $invoice['city'] ?>, <?= $invoice['state'] ?> <?= $invoice['zip'] ?><br>
<?= $invoice['country'] == "US" ? "" : $invoice['country'] ?>
</div>

<hr class="clear">

<table id="items">
	<tr>
		<th>Item</th>
		<th>Amount</th>
	</tr>
	<tr>
		<td>infinityDrive <?= $plan ?> Monthly Service Charge</td>
		<td><?= money($invoice['invoice_amount']) ?></td>
	</tr>
	<tr>
		<td class="total">Total:</td>
		<td><?= money($invoice['invoice_amount']) ?></td>
	</tr>
</table>

<hr>

<div id="footer">
	The amount of <?= money($invoice['invoice_amount']) ?>
	<?= $payment['completed'] == 't' ? "was" : "will be" ?>
	charged to your <?= cardtype($cc) ?> ending in the digits <?=
	last($cc, 4) ?> on <?= $invoice['invoice_date'] ?>.
</div>

<div id="footer">
	Thanks for choosing infinityDrive!
</div>

<hr>

<div class="noprint" id="returnlink">
	<a href="billing.php">return to billing page</a>
</div>

</div>

</body>
</html>
