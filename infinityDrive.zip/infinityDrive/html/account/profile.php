<? require_once("defs.inc"); ?>
<?
	$fields = array("contact_name", "company", "email");
	$params = request_to_params($fields);

	if (request("update"))
	{
		# validate
		$params['email'] = clean_email($params['email']);
		if (!check_email_format($params['email']))
			redirect("profile.php?edit=1&" . http_build_query($params) . "&error=bademail");

		sql_update("accounts", $params, "account_id=" . $account['account_id']);
		redirect("profile.php");
	}

	$edit = request("edit");

	function field($name)
	{
		global $account, $params, $edit, $offenders;
		$val = notnull($params[$name], $account[$name]);
		if ($offenders && in_array($name, $offenders))
			$error = " class=errorfield";
		if ($edit)
			return "<input type=text name=$name value=\"$val\"$error>";
		return $val;
	}
?>
<? include("template.inc"); ?>

<div id="mainheader">
	infinityDrive Account - Profile
</div>

<?
	$error = request("error");
	if ($error)
	{
		echo "<div class=errorbox>";
		echo "That email address is not valid.  Please enter your correct email address.";
		echo "</div>";
		$offenders = array("email");
	}

?>

<form>
<div id="profilebox">
	<table id="profileinfo">
	<tr><th>Username:</th><td><?= $account['account'] ?></td></tr>
	<tr><th>infinityDrive URL:</th><td><?= davurl() ?></td></tr>
	<tr><th>Created on:</th><td><?= substr($account['created'], 0, 10) ?></td></tr>
	<tr><th>Contact name:</th><td><?= field("contact_name") ?></td></tr>
	<tr><th>Company:</th><td><?= field("company") ?></td></tr>
	<tr><th>Email:</th><td><?= field("email") ?></td></tr>
	<tr><th>Plan:</th><td><?= $plans[$account['plan_id']][0] ?> <small><a href=updateplan.php>[upgrade]</a></small></td></tr>
	<tr><th>Users:</th><td><?= $account['users'] ?></td></tr>
	<tr><th>Shares:</th><td><?= $account['shares'] ?></td></tr>
	<tr><th>Quota:</th><td><?= $account['quota'] ?> Gigs</td></tr>
	</table>

	<div id="editprofile">
		<? if ($edit) { ?>
			<input type=submit name=update value="Update">
		<? } else { ?>
			<a href="profile.php?edit=1">Edit this information</a>
			&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
			<a href="password.php">Change password</a>
			&nbsp; &nbsp; &nbsp;
		<? } ?>
	</div>
</div>
</form>

<div id="billinglink">
	<a href="billing.php">Billing &amp; plan info</a>
</div>

<? include("template.inc"); ?>
