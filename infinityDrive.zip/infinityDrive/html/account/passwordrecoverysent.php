<?
	$no_login = 1;
	include("template.inc");
?>

<form name="ff">

<div id="loginbox">
	<h3>Password Recovery Email Sent</h3>
	A password recovery email has been sent.  You should receive this email momentarily.  If you have any questions or do not get this email, please contact <a href=mailto:support@infinitydrive.net>support@infinitydrive.net</a>.

</div>

</form>

<? include("template.inc"); ?>
