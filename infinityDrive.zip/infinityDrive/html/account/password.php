<? require_once("defs.inc"); ?>
<?
	$errors = array(
		"tooshort" => "The password is too short.  Please enter a longer password to ensure the security of your account.",
		"dontmatch" => "The passwords did not match.  Please try again.",
	);

	if (request("update"))
	{
		$pass1 = request("password1");
		$pass2 = request("password2");
		if (strlen($pass1) < 3 || strlen($pass2) < 3)
			redirect("password.php?error=tooshort");
		if ($pass1 != $pass2)
			redirect("password.php?error=dontmatch");

		sql_update("users", array("password" => $pass1), "account_id=" . $account['account_id'] . " AND username=" . sql_quote($account['account']));
		redirect("profile.php");
	}
?>
<? include("template.inc"); ?>

<form name="ff" method="post">

<div id="recoverybox">
	<div id="recoveryheader">Changing Password For <?= $account[account] ?></div>
	<table id="recoverytable">
		<?
			if (($error = request("error")))
				echo "<div id='loginfail'>" . $errors[$error] . "</div>";
		?>

		<tr><td align=right>New password:</td><td><input type="password" name="password1"></td></tr>
		<tr><td align=right>Retype password:</td><td><input type="password" name="password2"></td></tr>
		<tr><td align="center" colspan="2"><input id="loginbutton" type="submit" name="update" value="Update"></td></tr>
	</table>
</div>

</form>

<?  include("template.inc"); ?>
