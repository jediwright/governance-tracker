<?
	require_once("defs.inc");

	fileman_setdir();

	$file = $_REQUEST['file'];
	$pathfile = fullpath($file);

	check_read($pathfile);

	if (!file_exists($pathfile))
		redirect("fileman.php");

	$content = mime_content_type($pathfile);
	if ($content != "text/html")
	{
		# Better to display certain file types (images, documents) inline so that IE and
		# Moz display them directly, instead of looking for a plugin.
		if (preg_match("/^image/", $content) || $content == "application/pdf" ||
				$content == "text/plain")
			$dispos = "inline";
		else
			$dispos = "attachment";

		header("Content-type: $content");
		header("Pragma: public");
		header("Content-disposition: $dispos; filename=$file");
		header("Content-length: " . filesize($pathfile));
	}

	$fp = fopen($pathfile, "r");
	fpassthru($fp);
	fclose($fp);
?>
