<?
	require_once("defs.inc");

	fileman_setdir();

	$file = $_FILES['file'];
	if ($file && strlen($file['name']) > 0)
	{
		$pathfile = fullpath($file['name']);
		check_write($pathfile);

		if (!move_uploaded_file($file['tmp_name'], $pathfile))
			error("Trouble with file upload", "upload of filename " . $file['name'] . " failed to directory " . $dir);
	}

	redirect(filemanurl());
?>
