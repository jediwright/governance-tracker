<? require_once("defs.inc"); ?>
<?
	$q = $_REQUEST['q'];
	if (!$q)
		$search_sql = "true";
	else
	{
		$q = strtolower(trim($q));
		$q = preg_replace("/[^a-z0-9 ]/", "", $q);

		$words = split(" ", $q);
		$params = array();
		foreach ($words as $word)
			$params[] = "(lower(title) like '%$word%' OR search_terms like '%$word%')";
		$search_sql =  join(" AND ", $params);
	}

	$offset = notblank(max(0, request_numeric("offset")), 0);
	$PER_PAGE = 10;

	$sql = "SELECT * FROM knowledgebase WHERE " . $search_sql . " ORDER BY popularity DESC OFFSET $offset LIMIT " . ($PER_PAGE+1);
	$results = select_all($sql);

	# we selected one more than we needed to know whether to paginate; so get rid of the extra entry
	if (count($results) > $PER_PAGE) {
		$paginate = true;
		$results = array_splice($results, 0, $PER_PAGE);
	}
?>
<? include("template.inc"); ?>

<div style="margin: 2em; margin-right: 5em;">

	<div id="knowledgeheader">Knowledge Base Search Results</div>

	<ol id="knowledgeresults" start="<?= $offset+1 ?>">
	<?
		foreach ($results as $result)
		{
		?>
			<li>
				<h3><a href="knowledgebase.php?doc=<?=$result{'document'}?>"><?= $result{'title'} ?></a></h3>
				<p><?= $result{'summary'} ?></p>
			</li>
		<?
		}
	?>
	</ol>

	<? if ($results && $offset > 0) { ?>
		<div id="knowledgepager_prev">
			<a href="searchknowledge.php?q=<?= urlencode($q) ?>&offset=<?= ($offset-$PER_PAGE) ?>">&lt; Previous <?= $PER_PAGE ?> results</a>
		</div>
	<? } ?>

	<? if ($paginate) { ?>
		<div id="knowledgepager_next">
			<a href="searchknowledge.php?q=<?= urlencode($q) ?>&offset=<?= ($offset+$PER_PAGE) ?>">Next <?= $PER_PAGE ?> results &gt;</a>
		</div>
	<? } ?>

	<? if (!$results) { ?>
		<h3>Sorry, no matches found</h3>
		<div style="width: 40em; margin-left: 10em;">
			<p>Try using fewer or simpler keywords.  For example, instead of "setup infinitydrive windows system" try "setup windows" or even just "windows".</p>
			<p>You can even search for partial matches like "set" or "wind".</p>
			<p style="text-align: center;"><a href="support.php">Click here to try a different search.</a></p>
		</div>
	<? } ?>

	<? if ($q) { ?>
	<div id="didntfind">
		Didn't find what you were looking for?
		<a href="searchknowledge.php">Try browsing the entire knowledge base.</a>
	</div>
	<? } ?>

	<div id="knowledgeheader">
	</div>
</div>

<? include("template.inc"); ?>
