<?
	require_once("defs.inc");
	require_once("zip.inc");

	fileman_setdir();

	$fname = $_REQUEST['file'];
	if (strlen($fname) < 1)
		error("No file specified", "empty filename");
	$fname = fullpath($fname);
	check_read($fname);

	$out = unzip($fname);
	if ($out != 0)
		error("Difficulty extracting the zip archive", "result of unzip() : [$out]");

	redirect(filemanurl());
?>
