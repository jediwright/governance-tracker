<? require_once("defs.inc"); ?>
<?
	/// Find the share; if it doens't exist or they don't own it, disallow
	$id = request_numeric("id");
	if ($id) {
		$share = select_row("SELECT * FROM shares WHERE share_id=$id AND user_id={$_user[user_id]}");
		if (!$share) unset($id);
	}

	/// Variables
	$type = $id ? "Edit" : "Create";
	$fields = array("share", "description");
	$dav = share_local_path($id);

	/// Deleting a share
	if (request("delete") && $id)
	{
		$dir = "$dav/" . $share['share'];
		if (!dir_is_empty($dir))
			error("There are still files in that share.  Please delete them before removing it.");

		rmdir($dir);
		sql_delete("shares", "share_id=$id AND user_id=" . $_user[user_id]);
		redirect("shares.php");
	}

	/// Creating or updating a share
	if (request("edit"))
	{
		/// Validate
		$params = request_to_params($fields);
		$params['share'] = preg_replace("/[^A-Za-z0-9_ ]/", "", trim($params['share']));
		if (strlen($params['share']) < 1) $offenders[] = "share";
		if ($offenders)
			redirect("shareedit.php?" . http_build_query($params) . "&offenders=" . join(",", $offenders));

		sql_query("BEGIN");

		if ($id) {
			/// Update existing - rename on disk
			sql_update("shares", $params, "share_id=$id AND user_id={$_user[user_id]}");
			if ($share['share'] != $params['share'])
				rename("$dav/" . $share['share'], "$dav/" . $params['share']);
		}
		else 
		{
			/// Create a new share
			if (select_one("SELECT count(*) FROM shares WHERE share=" . sql_quote($params['share']) . " AND user_id=". $_user['user_id']) > 0)
				redirect("shareedit.php?error=inuse&" . http_build_query($params) . "&offenders=share");
			if (!create_share($params))
				error("couldn't make share");
		}

		/// User permissions
		$user = request("user");
		if (count($user))
		{
			foreach ($user as $user_id => $access)
			{
				$read = ($access % 2 == 1 ? 't' : 'f');
				$write = (floor($access/2) % 2 == 1 ? 't' : 'f');
				$vals = array("read" => $read, "write" => $write);
				// by using an update, we ensure that no new users or shares can be inserted into the table this way
				sql_update("share_permissions", $vals, "share_id=$id AND user_id=$user_id");
			}
		}

		sql_query("COMMIT");
		redirect("fileman.php");
	}
?>
<? include("template.inc"); ?>

<div id="mainheader">
	infinityDrive Account - <?= $type ?> Share
</div>

<?
	$offenders = request("offenders");
	$error = request("error");
	if ($error || $offenders)
	{
		echo "<div id='errorshare'>";
		$offenders = split(",", $offenders);
		if ($error) echo "That share name is already in use.  Please choose another.";
		else echo "The red-highlighted fields below were not entered correctly.";
		echo "</div>";

		// fill in values from url
		$share = request_to_params($fields);
	}

	function checkerror($field)
	{
		global $offenders;
		if (!$offenders || !in_array($field, $offenders))
			return;
		return " style='border: 1px solid red;'";
	}
?>

<form>
<input type=hidden name=id value=<?= $id ?>>

<table id="shareedit">
<tr><th>Share:</th><td <?= checkerror("share") ?>><input type=text name=share value="<?= $share['share'] ?>"></td></tr>
<tr><th>Description:</th><td <?= checkerror("description") ?>><input type=text name=description value="<?= $share['description'] ?>"></td></tr>

<?
	if ($share)
	{
		$sql = "SELECT * FROM users LEFT JOIN (SELECT * FROM share_permissions WHERE share_id = $id) as p USING (user_id) WHERE share_id={$share[share_id]} ORDER BY user_id";

		$users = select_all($sql);

		if (count($users) > 0)
			echo "<tr><th colspan=2 style='text-align: center;'>Share Access</th></tr>\n";

		function permission($user)
		{
			global $access_options;
			$select = ($user[read] == 't' ? 1:0) + ($user[write] == 't' ? 2:0);
			return makeselect("user[" .$user[user_id] . "]",$access_options,$select);
		}

		foreach ($users as $u)
			echo "<tr><th>$u[username]</th><td>". permission($u) ."</td></tr>\n";
	}
?>
</table>

<div id="edituserbutton">
	<input type=submit name=edit value="<?= $type ?>">
</div>
</form>

<form action="invite.php">
<input type=hidden name=share_id value=<?= $id ?>>
<table id="shareedit" style="margin-top: 1em;">
	<tr><th colspan=2 style='text-align: center;'>Invite User</th></tr>
	<tr><th>Email:</th><td><input type="text" name="email"></td></tr>
	<tr><td colspan=2 style='text-align: center;'><input type="submit" name="invite" value="Invite"></td></tr>
</table>
</form>

<? include("template.inc"); ?>
