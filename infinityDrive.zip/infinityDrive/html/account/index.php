<? include("template.inc"); ?>

<div id="mainheader">
	infinityDrive Account - Main Menu
</div>

<? if ($user['over_quota'] == 't') { ?>
	<div id="overquota">
		<h3>Warning!</h3>
		<p>Your user is currently over its quota limit.  You will not be able to put any new files on your infinityDrive until you delete some others.</p>
		<table id="overusage">
			<tr><td>Account quota:</td><td><?= round($user['quota'], 1) ?> GB</td></tr>
			<tr><td>Current usage:</td><td><?= round($user['disk_usage'] / GB, 1) ?> GB</td></tr>
		</table>
		<p>Or, how about buying some additional space?  Just <?= money($PRICE_PER_GIG) ?>/GB.  <a href="addons.php">Upgrade now!</a></p>
	</div>
<? } ?>

<?
	$survey = select_row("SELECT * FROM surveys WHERE user_id=" . $_user[user_id]);
	if ($survey && (!$survey['completed'] && $survey['dont_show'] != 't'))
	{ ?>
		<div id="asksurvey">
			<a href="survey.php">&gt; Take a survey to tell us what you think of infinityDrive so far</a>
		</div>
<?
	}
?>

<div id="mainmenucontainer">

	<div id="mainmenuitem">
		<h1><a href="profile.php">Account Profile</a></h1>
		<a href="profile.php"><img src="../images/head-silhouette.jpg" /></a>
		<p>View and update your contact information, or personalize your settings.</p>
	</div>

	<div id="mainmenuitem">
		<h1><a href="fileman.php">File Manager</a></h1>
		<a href="fileman.php"><img src="../images/home.jpg" /></a>
		<p>Access your infinityDrive from a web browser.</p>
	</div>

	<div id="mainmenuitem">
		<h1><a href="billing.php">Billing Options</a></h1>
		<a href="billing.php"><img src="../images/check.jpg" /></a>
		<p>View past and future billing cycles, or change your plan.</p>
	</div>

	<div id="mainmenuitem">
		<h1><a href="support.php">Support Center</a></h1>
		<a href="support.php"><img src="../images/book.jpg" /></a>
		<p>Documentation and support contact info.</p>
	</div>

	<div id="clear"></div>

</div>

<div id="logout">
	<a href="logout.php">[ logout ]</a>
</div>

<? include("template.inc"); ?>
