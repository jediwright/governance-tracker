<?
	$no_login = 1;
	require_once("defs.inc");

	$message = "";
	if ($_REQUEST['forgot'] and ($_REQUEST[account] or $_REQUEST[email]))
	{
		$account = addslashes(strtolower(trim($_REQUEST['account'])));
		$email = addslashes(strtolower(trim($_REQUEST['email'])));
		$where = " WHERE active IS TRUE ";
		if (strlen($account) > 0) $where .= " AND account = '$account'";
		if (strlen($email) > 0) $where .= " AND email = '$email'";
		$accounts = select_all("SELECT * FROM accounts $where ");

		if (count($accounts) == 0)
			$message = "No such account and/or email"; 
		else if (count($accounts) > 1)
			error("That email seems to be used on multiple accounts.  Please specify the account name you would like reset.","Password recovery matched multiple accounts to [$account/$password]",$accounts);
		else
		{
			// only send one per day - no spamming
			$count = select_one("SELECT count(*) FROM recovery WHERE recovery_time > current_date AND recovery_completed IS FALSE and account_id = {$accounts[0][account_id]}");

			if ($count == 0) send_password_recovery_email($accounts[0]);
			redirect("passwordrecoverysent.php");
		}
	}
	
	include("template.inc");
?>

<form name="ff">

<div id="loginbox">
	<h3>Forgot your password?</h3>
	We can't recover your old password for you but we can help you assign a new one.  Just enter your account name or email address the box below and press 'Submit'.  An email will be sent to the account holder requesting a password change.
	<div class=errorbox><?=$message?></div>
	<table id=forgottable>
	<tr>
		<th>Account Name</th>
		<td><input name=account value="<?= htmlspecialchars($_REQUEST[account]) ?>"></td>
	</tr>
	<tr>
		<th>and/or Email Address</th>
		<td><input name=email value=""></td>
	</tr>
	<tr>
		<th colspan=2><input type=submit name=forgot value="Submit"></th>
	</table>

	<div id="recoverynote">
		Please note, this is only for recovering account passwords.  If you are a user on a shared account, please contact your account administrator for a password reset.
	</div>

</div>

<div id="loginnoaccount">
	Don't have an account?  <a href="..">Get info and a free trial.</a>
</div>

</form>

<? include("template.inc"); ?>
