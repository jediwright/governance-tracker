<? require_once("defs.inc"); ?>
<?
	include("questions.inc");

	$sql = "SELECT * FROM surveys WHERE account_id=" . $account['account_id'];
	$data = select_row($sql);
	if (!$data) {
		 sql_insert("surveys", array("account_id" => $account['account_id']));
		$data = select_row($sql);
	}

	if ($data['completed'])
		redirect("surveydone.php");

	if ($_REQUEST['done'])
	{
		$answers = array();

		foreach ($_REQUEST as $k => $v)
		{
			if (!preg_match("/^ans_([0-9]+)(_[0-9]+)?/", $k, $matches)) continue;
			$qid = $matches[1];
			$choice = substr($matches[2], 1);

			$q = find_question($qid);
			if (!$q)
				error("Something went wrong with your survey submission.");

			$answer = null;
			$type = $q[2];
			if ($type == "radio") {
				$answer = $q[3][$v];
			}
			else if ($type == "checkbox") {
				if ($answers{$qid})
					$answer = $answers{$qid} . ",";
				$answer .= $q[3][$choice];
			}
			else #if ($type == "text" || $type == "$textarea")
				$answer = $v;

			if (strlen($answer) > 0)
				$answers{$qid} = $answer;
		}

		$sql = "UPDATE surveys SET completed=now() WHERE account_id=" . $account['account_id'];
		execute_sql($sql);

		foreach ($answers as $qid => $a) {
			$sql = "INSERT INTO survey_answers (survey_id,question_id,answer) VALUES ('" . $data['survey_id'] . "','$qid'," . sql_string($a) . ")";
			execute_sql($sql);
		}

		redirect("surveydone.php");
	}
?>
<? include("template.inc"); ?>

<h3>Customer Survey</h3>

Welcome to the infinityDrive customer survey.  We want your feedback to improve our service even more in the future.  Just answer the questions below as honestly as you can.  Tell us exactly what you think, the good, the bad, and the ugly!  You are welcome to skip any questions that you don't feel comfortable answering or don't understand.
<p>

<form method=post>

<table>
<?
	$num = 0;
	foreach ($questions as $ques)
	{
		$id = $ques[0];
		$text = $ques[1];
		$type = $ques[2];
		$choices = $ques[3];

		echo "<tr bgcolor=#e0e0e0><td>" . ($num+1) . ") $text</td></tr>";
		echo "<tr><td>";

		$varname = "ans_$id";
		if ($type == "text")
			echo "<input type=text name=$varname>";
		else if ($type == "textarea")
			echo "<textarea name=$varname rows=5 cols=60></textarea>";
		else if ($type == "radio" || $type == "checkbox")
		{
			echo "<table>";
			$i = 0;
			$x = 0;
			$w = (31 - strlen($choices[0])) / 5;
			foreach ($choices as $a)
			{
				if ($x == 0) echo "<tr>";
				$thisvar = $varname;
				if ($type == "checkbox") $thisvar .= "_$i";
				else $thisvar .= " value=$i";
				echo "<td><input type=$type name=$thisvar>$a</td>";
				echo "<td>&nbsp;</td>";
				if (++$x >= $w) { echo "</tr>"; $x = 0; }
				$i++;
			}
			echo "</table>";
		}
		else
			if ($dev) die("unknown type [$type] in question $num");

		echo "</td></tr>";
		$num++;
	}
?>
<tr bgcolor=#b0b0b0><td colspan=10 align=center><input style='background: rgb(50,250,50); font-weight: bold;' name=done type=submit value="Submit My Answers"></td></tr>
</table>

</form>

<? include("template.inc"); ?>
