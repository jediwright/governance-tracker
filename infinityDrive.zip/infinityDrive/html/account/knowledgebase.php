<? require_once("defs.inc"); ?>
<?
	$doc = preg_replace("/[^a-z0-9_\-]/", "", $_REQUEST['doc']);
	if (!$doc) error("Specify a knowledge base document");
	$data = select_row("SELECT * FROM knowledgebase WHERE document=" . sql_quote($doc));
	if (!$data) error("No such document");
?>
<? $nobg = 1; include("template.inc"); ?>

<div style="margin: 1em;">

	<div id="knowledgeheader">
		Knowledge Base Document
	</div>

	<div id="leftcolumn">
		<div id="leftsub">
			<h1><?= $data{'title'} ?></h1>
			<? include("knowledgebase/$doc.inc"); ?>
		</div>
	</div>

	<div id="clear"></div>

	<div id="knowledgeheader">
	</div>

	<div id="knowledgereturn">
		<a href="index.php">Return to the main menu</a>
	</div>

</div>

<? include("template.inc"); ?>
