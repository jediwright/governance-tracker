<? include("template.inc"); ?>

<h3>Survey Complete!</h3>

<p>Thanks for giving us your feedback, we really appreciate it and your answers will help us make our service even better for you and others in the future.<p>

<p><a href="index.php">Return to main menu</a></p>

<? include("template.inc"); ?>
