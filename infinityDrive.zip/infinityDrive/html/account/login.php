<?
	$no_login = 1;
	require_once("defs.inc");

	$user = strtolower(trim($_REQUEST['user']));

	if ($_REQUEST['login'])
	{
		$password = trim($_REQUEST['password']);

		# be very limited in what we allow on jump urls, otherwise this
		# can be a minor security flaw
		$jump = preg_replace("/[^a-z0-9_]/", "", $_REQUEST['jump']);

		if (strlen($user) > 0 && strlen($password) > 0 && select_one("SELECT count(*) FROM v_users WHERE username=" . sql_quote($user) ." AND password=" . sql_quote($password)) > 0)
			login($user, $jump);

		redirect("login.php", array("failed" => 1, "user" => $user));
	}

	if ($user)
		$onload = "javascript: document.ff.password.focus()";
	else
		$onload = "javascript: document.ff.user.focus()";
	
	include("template.inc");
?>

<form name="ff" method="post">
<input type="hidden" name="jump" value="<?= $_REQUEST['jump'] ?>">

<div id="loginbox">
	<div id="loginheader">Login to your infinityDrive account</div>
	<? if ($_REQUEST['failed'])
		{
			echo '<div id="loginfail">';
			echo 'Login failed, please try again<br>';
			echo '</div>'; 
		}
	?>
	<table id="logintable">
		<tr><td>Username</td><td><input type="text" name="user" value="<?= $user ?>"></td></tr>
		<tr><td>Password</td><td><input type="password" name="password"></td></tr>
		<tr><td align="center" colspan="2"><input id="loginbutton" type="submit" name="login" value="Log In"></td></tr>
	</table>

	<div id="forgot">
		<a href="forgotpassword.php">Forgot username or password?</a>
	</div>
</div>

<div id="loginnoaccount">
	Don't have an account?  <a href="..">Get info and a free trial.</a>
</div>

</form>

<? include("template.inc"); ?>
