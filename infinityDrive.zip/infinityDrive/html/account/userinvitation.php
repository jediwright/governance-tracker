<?
	$no_login = 1;
	require_once("defs.inc");

	$NO_INVITE = "Sorry, there is no such invitation in our database.";

	$errors = array(
		"invalid" => "The password supplied is not valid.  $password_rule",
		"nomatch" => "The passwords do not match, please try again.",
	);

	$hash = preg_replace("/[^0-9a-f]/", "", $_REQUEST['id']);
	if (!$hash) error($NO_INVITE);
	$invite = select_row("SELECT *,(invitation_date < now() - interval '3 days') as expired FROM v_users WHERE invitation=" . sql_quote($hash));
	if (!$invite) error($NO_INVITE);

	if ($invite['expired'] == 't')
		error("Sorry, this invitation is expired.  Please contact your account administrator to request a new invitation.");

	if ($_REQUEST['password1'])
	{
		$password1 = trim($_REQUEST['password1']);
		$password2 = trim($_REQUEST['password2']);
		if ($password1 != $password2)
			$error = "nomatch";
		else
		{
			$password = $password1;
			if (!valid_password($password))
				$error = "invalid";
			else
			{
				$params = array(
					"password" => $password,
					"hash" => md5($password),
					"invitation" => null,
					"invitation_date" => null,
				);

				sql_update("users", $params, "user_id=" . $invite['user_id']);

				login($invite['account'], $invite['username']);
			}
		}

		if ($error)
			redirect("userinvitation.php?id=$hash&error=$error");
	}
?>
<? include("template.inc"); ?>

<form name="ff" method="post">
<input type=hidden name=id value="<?=htmlspecialchars($hash)?>">
<div id="invitebox">
	<div id="inviteheader">Setting password for new user <b><?= $invite['username'] ?>@<?= $invite['account'] ?></b></div>
	<?
		$error = $_REQUEST['error'];
		if ($error) 
			echo "<div id=loginfail>" . $errors[$error] . "</div>";
		else
			echo "<div> Welcome to infinityDrive.  You can start using it as soon as you select a password.  </div>";
	?>
	<?  
		if ($message)
			echo "<div class=errorbox>$message</div>";
	?>
	<table id="invitetable">
		<tr><td align=right>Password:</td><td><input type="password" name="password1"></td></tr>
		<tr><td align=right>Retype password:</td><td><input type="password" name="password2"></td></tr>
		<tr><td align="center" colspan="2"><input id="loginbutton" type="submit" name="login" value="Set Password"></td></tr>
	</table>
</div>

</form>
<? include("template.inc"); ?>
