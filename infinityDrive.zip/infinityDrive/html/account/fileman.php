<? 
	require_once("defs.inc"); 
	require_once("zip.inc"); 

	fileman_setdir();

	# list escapeshellarg, but for an array
	function escapeshellarg_list($args)
	{
		$out = "";
		foreach ($args as $a)
		{
			if (contains_dotdot($a)) error("Invalid input values", "possible intrusion attempt: [$args]");
			$out .= " " . escapeshellarg($a);
		}
		return $out;
	}

	# move up a directory (used for ..)
	function dir_up($dir)
	{
		$dirs = split("/", $dir);
		unset($dirs[count($dirs)-1]);
		return join("/", $dirs);
	}

	# use our own special encoding to get rid of brackets (which don't work in
	# cgi params due to php's array converter)
	function encodefilename($fname)
	{
		$fname = preg_replace("/_/", "__", $fname);
		$fname = preg_replace("/\[/", "_1", $fname);
		$fname = preg_replace("/\]/", "_2", $fname);
		return $fname;
	}

	function decodefilename($fname)
	{
		$fname = preg_replace("/_1/", "[", $fname);
		$fname = preg_replace("/_2/", "]", $fname);
		$fname = preg_replace("/__/", "_", $fname);
		return $fname;
	}

	function makefieldname($fname)
	{
		return "files[" . encodefilename($fname) . "]";
	}

	# a number of functions take the list of checked files for processing
	function request_files($type="read")
	{
		global $_REQUEST;
		$files = $_REQUEST['files'];
		if (!$files || count($files) < 1)
			redirect(filemanurl());  # rather than throw an error, just reset them

		$files = array_keys($files);

		# a security check isn't necessary here, but might as well overdo it
		$newfiles = array();
		foreach ($files as $f)
		{
			$f = decodefilename($f);
			basepath($f);   # as part of the construction, it will check the validity
			check_access($f, $type);
			$newfiles[] = $f;
		}

		return $newfiles;
	}

	# give the file or dir name, add a line below for renaming if they are in that mode
	function makerename($fname)
	{
		global $rename, $prefix;
		if ($rename && in_array($prefix . $fname, $rename))
		{
			echo "<tr style='background: #d0d0d0;'>";
			echo td("<img src=../images/icons/rename.png> Rename to: <input type=text name=\"rename_files[$prefix$fname]\" value=\"$fname\" size=50 maxlength=128>", "colspan=3 style='text-indent: 2em;'");
			echo "</tr>";
		}
	}

	# determine if the file has been cut, and therefore should not be displayed
	# in the regular file listing
	function clipbin_cut($fname)
	{
		global $_SESSION, $prefix;
		if ($_SESSION['clipbin_cut'] && $_SESSION['clipbin'])
		{
			$fname = "$prefix$fname";
			foreach ($_SESSION['clipbin'] as $f)
				if ($f == $fname)
					return true;
		}

		return false;
	}

	# actions (note avoiding redirects wherever possible, for speed)
	if ($_REQUEST['copy'] || $_REQUEST['cut'])
	{
		$cut = ($_REQUEST['cut']) ? 1 : 0;
		$files = request_files($cut ? "write" : "read");
		$_SESSION['clipbin'] = $files;
		$_SESSION['clipbin_cut'] = $cut;
		redirect(filemanurl());
	}
	else if ($_REQUEST['paste'])
	{
		$files = $_SESSION['clipbin'];
		if (!$files || count($files) < 1)
			redirect(filemanurl());

		check_write($dir);

		# if they selected cut (rather than copy), we move (rename) the files instead
		# of copying them
		$move = $_SESSION['clipbin_cut'];

		foreach ($files as $f)
		{
			$src = basepath($f);
			$dst = fullpath(basename($f));
			if ($src != $dst)
			{
				if ($move)
					rename($src, $dst);
				else
					copyr($src, $dst);
			}
		}

		unset($_SESSION['clipbin']);
		unset($_SESSION['clipbin_cut']);
		redirect(filemanurl());
	}
	else if ($_REQUEST['emptyclipbin'])
	{
		unset($_SESSION['clipbin']);
		redirect(filemanurl());
	}
	else if ($_REQUEST['trash'])
	{
		$files = request_files("write");

		$trash = basepath($TRASH_DIR);
		if (!is_dir($trash)) mkdir($trash);
		foreach ($files as $f)
		{
			$pathfname = basepath($f);
			$pathtrash = basepath("$TRASH_DIR/" . basename($f));
			if (file_exists($pathtrash))
				rm($pathtrash);
			if ($pathfname != $pathtrash) rename($pathfname, $pathtrash);
		}

		redirect(filemanurl());
	}
	else if ($_REQUEST['rename'])
	{
		check_write($dir);
		# they've requested a rename, so give them some text boxes for doing so (part 1)
		$rename = request_files("write");
	}
	else if (request("rename_files"))
	{
		check_write($dir);
		# they typed in some files to rename (part 2)
		$files = request("rename_files");
		foreach ($files as $old => $new)
		{
			$old = basename($old);
			if ($old == $new) continue;
			if (file_exists($new)) error("$new already exists");
			$pathold = fullpath($old);
			$pathnew = fullpath($new);
			rename($pathold, $pathnew);
		}
		redirect(filemanurl());
	}
	else if ($_REQUEST['download'])
	{
		$files = request_files("read");
		if (count($files) == 1)
			redirect("get.php?" . http_build_query(array("d" => $dir, "file" => basename($files[0]))));

		# use relative pathnames for zip command
		for ($i = 0; $i < count($files); $i++)
			$files[$i] = basename($files[$i]);

		# multiple files - create an archive
		$arc = $_SESSION['username'] . "_download.zip";
		$patharc = "$SCRATCH_DIR/$arc";

		$out = zip($patharc, $files);
		if ($out != 0)
			error("Difficulty creating the zip archive for download", "zip command produced: [$out]");
	
		header("Content-type: " . mime_content_type($patharc));
		header("Content-disposition: attachment; filename=$arc");
		header("Content-length: " . filesize($patharc));
		$fp = fopen($patharc, "r");
		fpassthru($fp);
		fclose($fp);
		unlink($patharc);
		exit();
	}

	fileman_setdir();
	$prefix = $dir ? "$dir/" : "";

	if ($_REQUEST['mkdir'])
	{
		check_write($dir);
		$folder = $_REQUEST['folder'];
		if (strlen($folder) > 0)
		{
			if (is_dir($folder)) error("That folder already exists");
			else if (file_exists($folder)) error("There is already a file of that name");
			else
				mkdir($folder);
		}
		redirect(filemanurl());
	}
?>
<? $nobg = 1; include("template.inc"); ?>

<script language="javascript">
	// toggle the state of all checkboxes on the page
	function check()
	{
		var ff = document.ff;
		var count = ff.elements.length;
		for (i = 0; i < count; i++)
			ff.elements[i].checked = !ff.elements[i].checked;

		for (i = 0; i < count; i++)
			highlightRow(ff.elements[i]);
	}

	// highlight a file or dir row (call when selected)
	function highlightRow(t)
	{
		var row = t.parentNode.parentNode;
		if (t.checked)
		{
			if (row.className == "dirrow")
				row.className = "dirselected";
			if (row.className == "filerow")
				row.className = "fileselected";
		}
		else
		{
			if (row.className == "dirselected")
				row.className = "dirrow";
			if (row.className == "fileselected")
				row.className = "filerow";
		}
//			row.className = "unselected";
//			row.className = type + "row";
	}

	// select a row
	function selectRow(name)
	{
		var list = document.getElementsByName(name);
		var checkbox = list[0];
		checkbox.checked = !checkbox.checked;
		highlightRow(checkbox);
	}
</script>

<div id="filemanheader">
	<div id="header_dir">
		<a href="<?= filemanurl("", "") ?>"><img src="../images/icons/home.png" style="border: 0px;">/</a>
		<?
			if ($_share)
				echo "<a href=\"". filemanurl("") . "\">" . $_share[share] . "</a>/";

			$dirs = split("\/", $dir);
			for ($i = 0; $i < count($dirs); $i++)
			{
				if (strlen($dirs[$i]) < 1) continue;
				$descend = array_slice($dirs, 0, $i+1);
				$href = filemanurl(join("/", $descend));
				echo '<a href="' . $href . '">' . $dirs[$i] . "/</a>";
			}
		?>
	</div>
</div>

<? if ($_share) { ?>

<form name="ff">
<?= form_preservedir() ?>

<div id="actions">
	<?
		$actions = array(
			"copy" => "Copy",
			"cut" => "Cut",
			"paste" => "Paste",
			"rename" => "Rename",
			"download" => "Download",
			"trash" => "Trash"
		);

		// certain actions disable the action buttons, but we want to leave them
		// visible so as to retain continuity of the interface.
		if ($rename)
			$disable_all = 1;

		$disabled = array();
		if (!$_share[write])
			array_push($disabled, "cut", "paste", "rename", "trash");

		foreach ($actions as $name => $title)
		{
			echo "<input type='submit' name='$name' value='$title' class=button";
			if (in_array($name, $disabled) || $disable_all)
				echo " disabled='1'";
			echo ">";
		}
	?>
</div>

<div id="filelistcontainer">
	<table class="filelist">
	<tr>
		<th>Filename</th><th>Size</th><th><input type=button value=X onClick="check()">
	</th></tr>
	<?
		$dh = opendir(".");
		$filelist = array();
		$dirlist = array();
		while (($fname = readdir($dh)))
		{
			if (is_dir($fname))
				$dirlist[] = $fname;
			else if (is_file($fname))
				$filelist[] = $fname;
		}

		sort($dirlist);
		sort($filelist);

		foreach ($dirlist as $dirname)
		{
			if ($dirname[0] == "." && $dirname != "..") continue;
			if ($dirname == ".." && $dir == "") continue;
			if (clipbin_cut($dirname)) continue;

			$newdir = ($dirname == "..") ? dir_up($dir) : "$prefix$dirname";
			$fieldname = makefieldname($newdir);
			echo "<tr class=\"dirrow\" onClick=\"selectRow('$fieldname')\">";

			echo td("<a id=\"dir\" href=\"" . filemanurl($newdir) . "\"><img src=\"../images/icons/folder.png\" border=\"0\"> $dirname</a>");
			echo td("");

			$selectable = true;
			if ($dirname == "..")
				$selectable = false;
			else if ($dirname == "Trash" && $dir == "")
				$selectable = false;
			else if ($rename)
				$selectable = false;
			echo td($selectable ? "<input name=\"$fieldname\" type=checkbox onClick=\"selectRow('$fieldname')\">" : "");

			echo "</tr>\n";

			makerename($dirname);
		}

		foreach ($filelist as $fname)
		{
			if ($fname[0] == ".") continue;  # ignore dotfiles
			if (clipbin_cut($fname)) continue;

			$fieldname = makefieldname($prefix . $fname);
			echo "<tr class=\"filerow\" onClick=\"selectRow('$fieldname')\">";

			# some file types (images, html) we display inline
			$ext = null;
			if (preg_match("/\.([^.]+)$/", $fname, $matches))
				$ext = strtolower($matches[1]);

			$query_string = http_build_query(array("d" => $dir, "share" => $_share[share_id], "file" => $fname));
			$val = "<a href=\"get.php?$query_string\">$fname</a>";

			if ($ext == "zip")
				$val .= "&nbsp; &nbsp; &nbsp; <a href=\"extract.php?$query_string\">[extract]</a>";

			echo td($val);

			echo td(prettysize(filesize($fname)));

			$selectable = $rename ? false : true;
			echo td($selectable ? "<input name=\"$fieldname\" type=checkbox onClick=\"selectRow('$fieldname')\">" : "");

			echo "</tr>\n";

			makerename($fname);
		}
	?>
	</tr>
	</table>

	<? if ($rename) { ?>
	<div id="rename">
		<input type=submit name=do_rename value="Rename <?= count($rename) >= 2 ? "These Files" : "This File" ?>">
	</div>
	<? } ?>
</div>

</form>

<? } else { ?>

<div id="filelistcontainer">
	<table class="filelist">
	<tr><th>Share</th><th>Description</th><th>Owner</th><th>Access</th><th>Shared With</th></tr>
	<?
		$user_count_sql = "SELECT count(*) FROM share_permissions WHERE share_id=shares.share_id";
		$shares = select_all("SELECT *,($user_count_sql) as user_count FROM shares WHERE user_id={$_user[user_id]} OR share_id IN (select share_id from share_permissions where user_id={$_user[user_id]}) ORDER BY user_count,share_id");
		foreach ($shares as $share)
		{
			echo "<tr>";
			echo td("<a href=\"fileman.php?share={$share[share_id]}\">{$share[share]}</a>");
			echo td($share[description]);

			if ($share[user_id] == $_user[user_id])
				$owner = "You";
			else
				$owner = select_one("SELECT username FROM users WHERE user_id={$share[user_id]}");
			echo td($owner);

			if ($owner == "You")
				echo td("Full");
			else {
				$perms = select_row("SELECT * FROM share_permissions WHERE share_id={$share[share_id]} AND user_id={$_user[user_id]}");
				$perm_text = array();
				if ($perms[read] == 't') $perm_text[] = "read";
				if ($perms[write] == 't') $perm_text[] = "write";
				echo td(join(" &amp; ", $perm_text));
			}

			$text = "";
			if ($share[user_count] == 0)
				$text = "no one";
			else if ($share[user_count] <= 3) {
				$shared_with = select_vertical("SELECT username FROM share_permissions JOIN users USING (user_id) WHERE share_id={$share[share_id]}");
				$text = join(", ", $shared_with);
			}
			else
				$text = $share[user_count];
			// only the owner gets a hyperlink to edit it
			if ($share[user_id] == $_user[user_id])
				$text = "<a href=\"shareedit.php?id={$share[share_id]}\">$text</a>";
			echo td($text);

			echo "</tr>";
		}
	?>
	</table>

	<hr>
	<div><a href="shareedit.php">Create New Share</a></div>
</div>

<? } ?>

<div id="rightcolumn">

	<div id="clipbin">
		<h1>Clip Bin</h1>
		<?
			$clipbin = $_SESSION['clipbin'];
			if (!$clipbin || count($clipbin) < 1)
				echo '<div id="clipbin_empty">clip bin is currently empty</div>';
			else
			{
				foreach ($clipbin as $file)
					echo "<div id=\"clipbin_file\">$file</div>";

				echo "<div id=\"emptyclipbin\">";
				echo "<a href=\"" . filemanurl() . "&emptyclipbin=1\">[empty]</a>";
				echo "</div>";
			}
		?>
	</div>

	<? /* at the share level, uploads and new folders are disabled */ ?>
	<? if ($_share && $_share[write]) { ?>
		<div id="upload">
			<p>Upload a file</p>
			<form action="upload.php" enctype="multipart/form-data" method="post">
				<?= form_preservedir() ?>
				<input type="file" name="file" size="10" maxlength="255">
				<br>
				<input type="submit" value="Go">
			</form>
		</div>

		<div id="mkdir">
			<p>New Folder</p>
			<form>
				<?= form_preservedir() ?>
				<input type="hidden" name="mkdir" value="1">
				<input type="text" name="folder">
				<br>
				<input type="submit" value="Create">
			</form>
		</div>
	<? } ?>

	<div id="diskusage">
		<img src="dupie.php" />
	</div>

</div>

<? include("template.inc"); ?>
