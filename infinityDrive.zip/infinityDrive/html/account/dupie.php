<?
	require_once("defs.inc");
	include("piechart.inc");

	$used = round($account['disk_usage'] / GB, 1);
	$free = $account['quota'] - $used;

	$data = array(
		$used * 10 => $used . "GB Used",
		$free * 10 => $free . "GB Free",
	);

	show3dpiechart($data);
?>
