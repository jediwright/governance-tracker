<? require_once("defs.inc"); ?>
<?
	if (request("cancel"))
	{
		if (request("password") != $account['password'])
			redirect("cancel.php?error=password");

		$params = array(
			"canceled" => "now()",
			"active" => "false");
		sql_update("accounts", $params, "account_id=" . $account['account_id']);

		logout();
		redirect("inactive.php?account=" . $account['account'] . "&canceled=1");
	}
?>
<? include("template.inc"); ?>

<form name="ff">

<div id="recoverybox">
	<div id="recoveryheader">Cancel Account <?= $account[account] ?></div>

	<h3>We're glad to have you as a customer, and will be sorry to see you go!</h3>

	<p>Canceling your account immediately terminate your login and mounting access.  No further billing (or any billing, if you are still in your free trial) will be applied to your credit card.</p>

	<div class="warning">Please make absolutely certain you have retreived all of your files before canceling, as they will not be recoverable afterward!</div>

	<p>
		If you are <b>certain</b> you want to cancel your account, complete the form below and then click the button.
	</p>

	<div id="cancelform">
		<? if (request("error")) { ?>
			<div id="loginfail">
				That password was not correct.  Please enter your password to verify that you really wish to deactivate the account.
			</div>
		<? } ?>

		Password: <input type="password" name="password">
		<br>
		<input id="redbutton" type="submit" name="cancel" value="Cancel My Account">
	</div>
</div>

</form>

<?  include("template.inc"); ?>
