<? include("template.inc"); ?>

<div id="mainheader">
	infinityDrive Account - Support
</div>

<div id="supportbox">

	<div id="contact">
		<p>For questions not answered by the knowledge base, please email <a href=mailto:support@infinitydrive.net>support@infinitydrive.net</a>.</p>
		<? if (in_array($account{'plan'}, array("business", "enterprise"))) { ?>
			<p>For phone support, please call 877-414-7100, open M-F 9am - 9pm Pacific Standard Time, and dial extension 1.</p>
		<? } ?>
	</div>

	<div id="knowbase">
		<div id="knowbase_search">
			<p>Search our knowledge base by entering terms into the box below.</p>
			<p>For example, if you need help with infinityDrive setup on Windows, enter "setup windows" into the box.</p>

			<form action="searchknowledge.php">
			<div id="knowbase_searchbox">
					Search: <input type="text" name="q">
					&nbsp; <input type=submit name=go value=Go>
			</div>
			</form>
		</div>

		<div id="knowbase_common">
			<p>Or, select one of the common knowledge entries from the list below.</p>

			<ul>
			<?
				$docs = select_vertical_assoc("SELECT document,title FROM knowledgebase ORDER BY popularity DESC LIMIT 5");
				foreach ($docs as $doc => $title)
					echo "<li><a href=\"knowledgebase.php?doc=$doc\">$title</a></li>";
			?>
			</ul>
		</div>
	</div>

</div>

<? include("template.inc"); ?>
