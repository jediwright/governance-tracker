<? include("template.inc"); ?>

<div id="leftcolumn">
	
	<div id="leftsub2">
		<div id="clear"></div>
		<h1>infinityDrive Install Notes: Mac OS X</h1>

		<p> 
	Your infinity drive can be set up to be <a href=secure-insecure.php>secure or insecure</a>.
		</p>
		<p> MacOSX can only mount insecure infinityDrives by default.  If you need to access your data securely you can either use a free third party application called <a href="http://www.webdav.org/goliath/" target=_blank>Goliath</a> or access your files from the <a href="fileman.php">File Manager</a> when logged into your account. 

	</div>
</div>

<div id="clear"></div>

<? include("template.inc"); ?>
