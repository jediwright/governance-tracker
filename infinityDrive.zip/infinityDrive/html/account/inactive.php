<? $no_login = 1; include("template.inc"); ?>
<?
	$accountname = request("account");
	$canceled = request("canceled");
?>

<div id="recoverybox">
	<div id="recoveryheader">Account <?= $accountname ?>
		<? if ($canceled) { ?> has been canceled
		<? } else { ?> is inactive <? } ?>
	</div>
	<br>

	<p>If you would like to reactivate it, please contact us at <?= obfuscated_email_link() ?>.</p>

	<? if ($canceled) { ?>
		<h3>Thank you for trying infinityDrive!</h3>
	<? } ?>

</div>

<?  include("template.inc"); ?>
