<? include("template.inc"); ?>

<div id="maincolumn">
	
	<div id="leftsub">
		<h1>Solutions</h1>
		<h2>A single product - many solutions</h2>
		<p>
		infinityDrive doesn't just mean limitless storage space - it means limitless
		possibilities.  Here are just a few of the innovative ways that infinityDrive
		can handle your data storage needs.
		</p>
		<h2>Backup</h2>
		<p>
		Forget the hassle and limited storage of physical media like tapes or CD-R.
		infinityDrive makes it easy to create completely automated backups from
		your desktop or server - weekly, daily, or even hourly.
		</p>
		<h2>Colaborative file sharing</h2>
		<p>
		Emailing documents back and forth in your office?  Tired of the hassle of
		klunky email attachments?  Never know who has the latest version of the
		document?  Relax, infinityDrive is the perfect solution.  Everyone in your
		workgroup can save their files directly onto the infinityDrive shared space.
		You'll all breathe a sigh of relief, and the boss will love the improved
		productivity.
		</p>
		<h2>Access files at home, work, on vacation - anywhere!</h2>
		<p>
		How many times have you uttered the phrase, "Oh, that's on my _____
		computer, I can't get it right now?"  Fill in the blank with "home",
		"work", "laptop", or even "friend's".  How would you like to never
		say this again?
		</p>
		<p>
		Enter infinityDrive.  Go anywhere worldwide, laptop or no, and anywhere
		there's an internet connection you can access your infinityDrive just like
		at home.
		</p>
		<h2>Shared calendaring</h2>
		<p>
		By moving your calendar files onto your infinityDrive, you can access the same
		calendar from many computers.  If you have a multi-user infinityDrive account
		(anything above the Personal plan) everyone using your share can access the
		same calendar file, instantly sharing all data.  Apple's iCal, KDE's KOrganizer,
		and many versions of Outlook support shared calendaring in this manner.
		</p>

		<div id="clear"></div>
	</div>
</div>

<?= showrightcol() ?>

<div id="clear"></div>

<? include("template.inc"); ?>
