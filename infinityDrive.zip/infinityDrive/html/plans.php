<? include("template.inc"); ?>

<div id="maincolumn">
	
	<div id="leftsub">
		<h1>Plans</h1>

		<img src="images/plan.jpg" style="float: left; margin: 3px;" />

		<div id="planheader">click on any plan name for details</div>

		<div>
			<table id="plans">
			<tr id="plansmallheader"><td>Plan</td><td>Monthly Cost</td><td>Size</td><td>Users</td><td>Shares</td></tr>
			<?
				foreach ($plans as $p)
				{
					echo '<tr id="plans' . $p[0] . '">';
					echo td("<a href=\"plandetail.php?plan=$p[0]\">$p[0]</a>");
					echo td(money($p[1]));
					echo td($p[2] . " GB");
					echo td(plural($p[3], "user"));
					echo td(plural($p[4], "share"));
					echo "</tr>";
				}
			?>
			</table>
		</div>

		<div id="clear"></div>

		<p>Choose the plan that's right for you.  There are no startup costs and no long-term contract.  Upgrade or downgrade your plan instantly, or even cancel completely, at any time.</p>
		<p>Grow your infinityDrive to any size up to 3000GB - just $<?= $PRICE_PER_GIG ?>/GB/month!</p>

		<div id="clear"></div>
	</div>
</div>

<?= showrightcol() ?>

<div id="clear"></div>

<? include("template.inc"); ?>
