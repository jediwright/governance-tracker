<? if (!$template_was_included) include("template.inc"); ?>

<div id="maincolumn">
	
	<div id="leftsub">
		<h1>Oops</h1>
		<p>We're sorry, an error has occured processing your request.  The error message is:</p>
		<div id="errormsg"><?= notnull($MSG, "Internal website error") ?></div>
		<p>An email has been sent to our site admin to take a look at the issue.  If you need assistance please <a href=contact.php>contact us</a>.</p>
	</div>
</div>

<?= showrightcol() ?>

<div id="clear"></div>

<? include("template.inc"); ?>
