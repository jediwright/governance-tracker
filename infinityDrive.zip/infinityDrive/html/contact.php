<? include("template.inc"); ?>

<div id="maincolumn">
	
	<div id="leftsub">
		<h1>Contact</h1>
		<img src="images/office.jpg" style="float: right; margin: 1em; border: 1px solid black;" />
		<p>For support, please log in to your account and use the support link there for fastest service.  (If you are having difficulty loging in, you can use the contact info below.)</p>
		<p id="address">
			infinityDrive Corporation<br>
			<?= $ADDRESS[0] ?><br>
			<?= $ADDRESS[1] ?>
		</p>

		<p style="font-size: 120%;">Email: <?= obfuscated_email_link() ?></p>
		<p>Phone: <?= $PHONE ?> (9am - 9pm PST, Monday through Friday)</p>

		<div id="clear"></div>
	</div>
</div>

<?= showrightcol() ?>

<div id="clear"></div>

<? include("template.inc"); ?>
